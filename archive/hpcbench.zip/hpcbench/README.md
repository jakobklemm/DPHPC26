# hpcbench — build-configuration benchmark harness

Give it a build-configuration vector → it builds the application with exactly that
configuration, runs a fixed benchmark protocol, and appends one JSON record (config,
vector, hardware features, machine state, build stats, performance) to a results file.
First application: **llama.cpp** (targets `cpu` and `gpu`). The core is app-agnostic;
GROMACS, WarpX, MILC and Grid get their own adapter in `hpcbench/apps/`.

Pure Python 3.9+ standard library.

## Setup (Ubuntu 24.04, also inside WSL2 on Windows)

```bash
scripts/install_deps_ubuntu.sh   # all compilers/libraries the space uses (WITH_MKL=1 adds Intel MKL)
scripts/setup_llamacpp.sh        # llama.cpp at the pinned commit + model, prints the model sha256
./bench protocol llamacpp        # the fixed benchmark protocol and its id
./bench hwinfo                   # detected hardware features
```

On Windows: work inside WSL in `~/hpcbench`, never under `/mnt/c` (several times slower builds).

## Usage

```bash
./bench space llamacpp --target cpu      # parameter list = vector order, with defaults

# one configuration, three equivalent ways (unset parameters keep their defaults)
./bench run llamacpp --target cpu --vector 3,1,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,0,0
./bench run llamacpp --target cpu --config configs/llamacpp_cpu_portable_avx2.json
./bench run llamacpp --target cpu --set compiler=clang-18 --set GGML_NATIVE=0 --set GGML_OPENMP=0

# a sweep: N random configs this machine can run, then run them all
./bench sample llamacpp --target cpu -n 25 --seed 1 --only-supported --out cpu_s1.jsonl
./bench run llamacpp --target cpu --batch cpu_s1.jsonl

# flat table for the surrogate model (cfg.*, vec.*, hw.*, load.*, build.*, m.*)
./bench export llamacpp --target cpu --ok-only --csv llamacpp_cpu.csv
```

## CPU configuration space (28 parameters)

| group | parameters |
|---|---|
| toolchain | `compiler` gcc-12/13/14, clang-17/18/19 · `opt_level` O3/O2/O1/Os · `fast_math` · `unroll_loops` · `lto` · `shared_libs` |
| ISA | `cpu_variants` single/all (runtime dispatch over all x86 variants) · `GGML_NATIVE` · `mtune` none/generic/native · SSE4.2, AVX, AVX2, FMA, F16C, BMI2, AVX-VNNI, AVX-512 (+VBMI, VNNI, BF16), AMX (TILE, INT8, BF16) |
| ggml | `GGML_OPENMP` · `GGML_LLAMAFILE` · `GGML_CPU_REPACK` · `blas` none/OpenBLAS/BLIS/MKL/AOCL · `GGML_ZENDNN` |

Conditional parameters (ISA flags only when `GGML_NATIVE=0`, AVX-512 sub-flags only with
AVX-512, …) are normalised when inactive, so equivalent builds share one hash and are built once.
That leaves ~767 million distinct configurations; ~1.8 million run on a Zen 3 CPU with the
Ubuntu packages above. Configurations that can't run on a machine (missing ISA, missing library)
are recorded as `skipped` with the reason.

Deliberately **not** varied: debug/sanitizer options, options for other platforms
(Metal, CUDA, SYCL, ARM KleidiAI …), linker choice, PGO.

`fast_math=1` means `-ffast-math -fno-finite-math-only` (ggml refuses to build without the latter); it can
change numerical results, and llama-bench measures speed only. `lto=1` with clang links with lld/llvm-ar.

Optional, manual installs: **AOCL** (AMD's BLAS) from amd.com, then `export AOCL_ROOT=/opt/AMD/aocl/...`;
**ZenDNN** built once, then `export ZENDNN_ROOT=...`.

**GPU space** (`--target gpu`, all layers on the GPU): `backend` hip/vulkan, HIP graphs, VMM,
MFMA, flash-attention kernels (+ all quants), MMQ vs hipBLAS, HIP -O level, unsafe FP atomics.
The GPU arch is detected via `rocminfo`; override with `LLAMACPP_GPU_TARGETS=gfx1100`.

**Vulkan on native Windows** (`--target vulkan`, all layers on the GPU, same protocol as `gpu`):
for GPUs Docker can't reach on Windows (any AMD card; ROCm on WSL only covers a few).
Host side: `compiler` cl/clang-cl, `opt_level` /O2 /O1 /Ox, `lto`, `shared_libs`, `isa` native/avx2/avx/sse42
(+ BMI2), OpenMP, llamafile, repack. GPU side: the Vulkan backend has no performance CMake options, so its
kernel paths are switched at run time (`GGML_VK_DISABLE_*` / `GGML_VK_FORCE_MMVQ`, stored as `run_env`):
fp16, integer dot product, MMVQ auto/force/off, cooperative matrix, fusion, graph optimisation. Configs that
differ only in these share one build. `--only-supported` keeps only what this CPU (CPUID probe) and GPU
(`vulkaninfo`) support. One script does everything, from PowerShell in this folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\windows_vulkan.ps1 -Setup   # llama.cpp + model into C:\hpcb
powershell -ExecutionPolicy Bypass -File .\scripts\windows_vulkan.ps1 -Test    # 2 configs
powershell -ExecutionPolicy Bypass -File .\scripts\windows_vulkan.ps1 -N 50    # 50 random supported configs
powershell -ExecutionPolicy Bypass -File .\scripts\windows_vulkan.ps1 -Export  # .\export\vulkan-results.csv
```
Needs Visual Studio 2022 Build Tools ("Desktop development with C++"), the Vulkan SDK, Git and Python 3.

## Benchmark protocol — what exactly is measured

`./bench protocol llamacpp` prints it, together with a **protocol_id**. Everyone in the study must
show the same id; every record stores it, and results with different ids must not be compared.

| item | value |
|---|---|
| code | llama.cpp commit `23f7aabc16c72f6f707dba227251c35d7bd1ed96`, only `llama-bench` built |
| model | Qwen2.5-1.5B-Instruct, Q4_K_M GGUF (1.1 GB), identified by sha256 |
| test `pp512` | process a 512-token prompt in one batch → prompt-processing tokens/s (compute-bound) |
| test `tg128` | generate 128 tokens one at a time → generation tokens/s (memory-bandwidth-bound) |
| repetitions | 5 (+1 warm-up run llama-bench does automatically); mean, std, all samples stored |
| batch / ubatch | 2048 / 512 |
| flash attention | `on` (cpu), `auto` (gpu) |
| threads | number of **physical** cores of the machine (machine-specific, stored per record) |
| GPU offload | 0 layers (cpu), all layers (gpu) |

Fixing the model across machines: the first person runs `scripts/setup_llamacpp.sh`, shares the
printed sha256, and everyone else runs `EXPECTED_SHA256=<hash> scripts/setup_llamacpp.sh`.
Use the same OS image (Ubuntu 24.04) so compiler versions match; they are recorded in `hardware`.

## Disk usage

A full llama.cpp build directory is ~100–200 MB (objects, static libs). After each successful build
only `bin/` (+ `CMakeCache.txt`) is kept, a few MB per configuration, so re-runs don't need to rebuild.
`--keep-build-dir` keeps everything, `--clean-builds` deletes the binary too (0 MB, but a re-run rebuilds).
Each record stores `build.dir_bytes_full` and `build.dir_bytes_kept`. `rm -rf builds/` is always safe.

## Measurement noise

- Before every run the harness records machine state in `load_before`: Linux CPU usage, load average,
  free memory, and under WSL also **Windows** CPU usage and the active power plan
  (Linux can't see Windows programs otherwise). If CPU usage is above `--max-busy` (10 %) it warns
  and sets `idle_ok=false` in the record.
- Each result prints its variation, e.g. `pp512_tps=327.35 (±0.8%)`. Above ~3 %, redo it with
  `--force --runtime repetitions=10`.
- Before a session: close browser/games/updaters, plug in laptops, Windows power plan
  "High performance", don't use the machine while it runs. ccache is off so build times are real.

## Adding the next application

Subclass `CMakeApp` in `hpcbench/apps/<app>.py`: define `targets` (lists of `Param`),
`cmake_args`, `runtime_params`, `PROTOCOL_KEYS`, `run` (status + metrics dict), and register it in
`hpcbench/apps/__init__.py`. Build orchestration, hashing, caching, storage and export are shared.

## ETH student cluster (NVIDIA GPUs), driven from a Mac

Target `cuda`: llama.cpp built with the CUDA backend, all layers on the GPU. 6 parameters,
72 distinct configurations per GPU (`./bench space llamacpp --target cuda`):

| # | parameter | values | meaning |
|---|---|---|---|
| 0 | `gpu_target` | exact, generic | machine code for exactly this GPU (`sm_XX-real`) vs. PTX only, JIT-compiled by the driver |
| 1 | `GGML_CUDA_GRAPHS` | 0, 1 | CUDA graphs |
| 2 | `GGML_CUDA_FA` | 0, 1 | flash-attention kernels compiled in |
| 3 | `quant_matmul` | auto, force_mmq, force_cublas | quantised matmul: llama.cpp decides / own MMQ kernels / cuBLAS |
| 4 | `GGML_CUDA_NO_VMM` | 0, 1 | CUDA virtual memory management off |
| 5 | `ptxas_opt` | O3, O2 | device-code optimisation level (only with `exact`) |

Not included, on purpose: `-use_fast_math` (ggml always uses it), `GGML_CUDA_FA_ALL_QUANTS`
(only affects quantised KV caches, the protocol uses f16), NCCL / peer copy (multi-GPU only).

Workflow (all from the Mac, inside this folder; ETH network or VPN needed for ssh):

```bash
cluster/mac.sh push            # first run creates cluster/config.env -> fill in user + course tag, push again
cluster/mac.sh setup           # on the login node: llama.cpp + model + list of all 72 configs
cluster/mac.sh smoke 5060ti    # ONE default build: checks everything works, shows the build time
cluster/mac.sh log             # follow it
cluster/mac.sh submit          # all configs on all GPUs in config.env, one GPU after the other
cluster/mac.sh status          # queue + progress per GPU
cluster/mac.sh pull            # one JSON per measured configuration -> ./cluster-results/json/
```

Each job builds in the node's local `$TMPDIR`, records every configuration as soon as it is
measured, stops 15 min before its wall time, resubmits itself until all 72 configs of its GPU are
done (at most `MAX_CHAIN` times), then submits the next GPU. Interrupting at any point loses at
most the configuration in progress; the config list is shuffled, so a partial run is a random sample.
The CUDA module is picked per GPU (newest available; CUDA < 13 for the GTX 1080 Ti, which CUDA 13
no longer supports). On GB10 (ARM CPU, shared CPU/GPU memory) the page cache is dropped before
every benchmark, as the cluster documentation asks.

One JSON per configuration (`<gpu>__<config_hash>.json`):
`gpu` (name, compute capability, SMs, VRAM, L2, bus width, measured memory bandwidth, CUDA version,
driver, clocks, power limit), `host` (CPU of the node), `build_configuration` (values, vector,
parameter order, cmake arguments, llama.cpp commit), `performance` (pp512/tg128 tokens/s, std,
coefficient of variation, every repetition, build time), `protocol`, `machine_state`.

## Inside the XaaS container (Docker)

`xaas/Dockerfile` starts from the empty XaaS source-container base image
(`spcleth/xaas:source-base-x86-24.04`, or `...-arm-24.04` on ARM / Apple Silicon; see
`xaas/source/dockerfile_creator.py` in github.com/spcl/xaas-containers), installs the toolchain,
puts llama.cpp (pinned commit) into `/opt/llama.cpp` and the harness into `/opt/hpcbench`.
Every sampled configuration is compiled from that source inside the container.

```bash
docker build -f xaas/Dockerfile -t hpcbench-xaas .                 # from this folder
docker run --rm -v "$PWD/xaas-data:/data" hpcbench-xaas             # 200 random configs
docker run --rm -v "$PWD/xaas-data:/data" -e N=200 -e SEED=1 -e FIX="GGML_NATIVE=1" hpcbench-xaas
docker run --rm -it hpcbench-xaas space                             # show the parameter space
```

Output in `xaas-data/` on the host:
- `json/<cpu>__cpu__<config_hash>.json`: one file per configuration, written as soon as it is
  measured: `build_configuration` (parameter values, vector, cmake arguments incl. compiler
  flags), `performance` (pp512/tg128 tokens/s, std, every repetition, build time), `host`
  (hardware features), `protocol`. Failed/skipped configs also get a file (`__build-failed` etc.).
- `results/llamacpp/xaas__cpu.jsonl`: all records; `configs/sample_*.jsonl`: the sampled list.

The sample is drawn once (`SEED`) and only contains configurations this machine can run.
Rerunning the same command resumes; finished configurations are skipped.

### On Windows without a Linux terminal

Unzip, open PowerShell in the `hpcbench` folder (Shift + right-click → "Open PowerShell window here"):

```powershell
powershell -ExecutionPolicy Bypass -File .\xaas\run.ps1 -Test     # quick check
powershell -ExecutionPolicy Bypass -File .\xaas\run.ps1           # 200 configs in the background
powershell -ExecutionPolicy Bypass -File .\xaas\run.ps1 -Status
powershell -ExecutionPolicy Bypass -File .\xaas\run.ps1 -Export   # .\export\xaas-json.zip + xaas-results.csv
```
Results: `hpcbench\xaas-data\json\` (normal Windows folder). Model: Docker volume `hpcbench-models`.
