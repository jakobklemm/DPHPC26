#!/bin/bash
# Samples N random build configurations, builds + benchmarks each one, and writes one JSON per
# configuration to /data/json. Rerunning the same command resumes where it stopped.
#
# Environment: N (200), SEED (1), REPETITIONS (5), FIX (e.g. "GGML_NATIVE=1 compiler=gcc-13"),
#              JOBS (build parallelism, default: all cores)
set -euo pipefail
cd /opt/hpcbench
[ "${1:-}" = "bash" ] && exec bash
[ "${1:-}" = "space" ] && exec ./bench space llamacpp --target cpu

mkdir -p /data/configs /data/json /data/results/llamacpp
echo "== hpcbench in XaaS container: $(. /etc/os-release; echo "$PRETTY_NAME"), $(nproc) cores"

# model (downloaded once into /data/models, verified by sha256 if EXPECTED_SHA256 is set)
scripts/setup_llamacpp.sh

FIXARGS=(); for f in $FIX; do FIXARGS+=(--fix "$f"); done
SAMPLE="/data/configs/sample_n${N}_seed${SEED}${FIX:+_$(echo "$FIX" | tr ' =' '_-')}.jsonl"
if [ ! -f "$SAMPLE" ]; then
  ./bench sample llamacpp --target cpu -n "$N" --seed "$SEED" --only-supported "${FIXARGS[@]}" --out "$SAMPLE"
fi
echo "== configurations: $SAMPLE ($(wc -l < "$SAMPLE"))"

./bench run llamacpp --target cpu \
  --batch "$SAMPLE" \
  --results /data/results/llamacpp/xaas__cpu.jsonl \
  --json-dir /data/json \
  --runtime "repetitions=$REPETITIONS" \
  -j "${JOBS:-$(nproc)}" \
  --clean-builds

echo "== done: $(ls /data/json | wc -l) JSON files in /data/json"
