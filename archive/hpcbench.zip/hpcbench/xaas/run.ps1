# llama.cpp build-configuration benchmark in the XaaS container - Windows / Docker Desktop.
# Run from PowerShell inside the hpcbench folder:
#
#   powershell -ExecutionPolicy Bypass -File .\xaas\run.ps1 -Test      # 3 configs, quick check (~20 min)
#   powershell -ExecutionPolicy Bypass -File .\xaas\run.ps1            # 200 configs in the background (~20 h)
#   powershell -ExecutionPolicy Bypass -File .\xaas\run.ps1 -Status    # progress
#   powershell -ExecutionPolicy Bypass -File .\xaas\run.ps1 -Export    # JSON zip + CSV into .\export
#   powershell -ExecutionPolicy Bypass -File .\xaas\run.ps1 -Stop      # stop the background run
#
# Options: -N 200  -Seed 1  -Repetitions 5  -Fix "GGML_NATIVE=1"  -Rebuild
param(
    [int]$N = 200,
    [int]$Seed = 1,
    [int]$Repetitions = 5,
    [string]$Fix = "",
    [switch]$Test, [switch]$Status, [switch]$Export, [switch]$Stop, [switch]$Rebuild
)

$Root  = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$Image = "hpcbench-xaas"
$Name  = "hpcb-run"
$Data  = Join-Path $Root "xaas-data"
$Models = "hpcbench-models"          # Docker volume: model downloaded once, read at full speed

function Fail($msg) { Write-Host "ERROR: $msg" -ForegroundColor Red; exit 1 }

docker version --format "{{.Server.Version}}" *> $null
if ($LASTEXITCODE -ne 0) { Fail "Docker Desktop is not running. Start it, wait until it says 'Engine running', try again." }

if ($Stop) {
    docker stop $Name | Out-Null
    Write-Host "Stopped. Run the script again (without -Stop) to continue where it left off."
    exit 0
}

if ($Status) {
    docker ps -a --filter "name=$Name" --format "table {{.Names}}\t{{.Status}}"
    $json = Join-Path $Data "json"
    $n = if (Test-Path $json) { (Get-ChildItem $json -Filter *.json).Count } else { 0 }
    Write-Host "`nFinished configurations: $n   (files in $json)`n"
    docker logs --tail 8 $Name 2>&1
    exit 0
}

if ($Export) {
    $json = Join-Path $Data "json"
    if (-not (Test-Path $json)) { Fail "No results yet in $json" }
    $out = Join-Path $Root "export"
    New-Item -ItemType Directory -Force -Path $out | Out-Null
    Compress-Archive -Path (Join-Path $json "*.json") -DestinationPath (Join-Path $out "xaas-json.zip") -Force
    docker run --rm -v "${Data}:/data" --entrypoint /opt/hpcbench/bench $Image `
        export llamacpp --target cpu --results /data/results/llamacpp/xaas__cpu.jsonl --ok-only --csv /data/xaas-results.csv
    Copy-Item (Join-Path $Data "xaas-results.csv") $out -Force
    Write-Host "Exported to $out :  xaas-json.zip (one JSON per configuration) and xaas-results.csv (one row per configuration)"
    exit 0
}

# build the image if it does not exist yet (or -Rebuild)
docker image inspect $Image *> $null
if ($LASTEXITCODE -ne 0 -or $Rebuild) {
    Write-Host "Building the image (first time ~10-20 min) ..."
    docker build -f xaas/Dockerfile -t $Image .
    if ($LASTEXITCODE -ne 0) { Fail "docker build failed - send the last lines above" }
}

if ($Test) {
    $TestData = "$Data-test"
    New-Item -ItemType Directory -Force -Path $TestData | Out-Null
    docker run --rm -v "${TestData}:/data" -v "${Models}:/data/models" -e N=3 -e REPETITIONS=2 $Image
    Write-Host "`nTest results: $TestData\json"
    exit 0
}

$running = docker ps --filter "name=$Name" --format "{{.Names}}"
if ($running) { Fail "A run is already in progress. Use -Status to follow it or -Stop to stop it." }
docker rm $Name *> $null          # remove a finished/stopped container; its results stay in xaas-data

New-Item -ItemType Directory -Force -Path $Data | Out-Null
docker run -d --name $Name `
    -v "${Data}:/data" -v "${Models}:/data/models" `
    -e N=$N -e SEED=$Seed -e REPETITIONS=$Repetitions -e FIX="$Fix" `
    $Image | Out-Null
if ($LASTEXITCODE -ne 0) { Fail "could not start the container" }
Write-Host "Started $N configurations in the background (container '$Name')."
Write-Host "Results appear one by one in: $Data\json"
Write-Host "Progress:  powershell -ExecutionPolicy Bypass -File .\xaas\run.ps1 -Status"
