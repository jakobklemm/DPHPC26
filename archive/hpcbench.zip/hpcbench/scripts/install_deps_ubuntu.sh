#!/usr/bin/env bash
# Installs every toolchain/library the cpu parameter space can use (Ubuntu 24.04 / WSL).
# Packages that fail are reported, not fatal: configs needing them are recorded as "skipped".
set -u
PKGS=(build-essential cmake ninja-build git curl unzip python3
      gcc-12 g++-12 gcc-13 g++-13 gcc-14 g++-14
      clang-17 clang-18 clang-19 libomp-17-dev libomp-18-dev libomp-19-dev
      lld-17 lld-18 lld-19 llvm-17 llvm-18 llvm-19
      libopenblas-dev libblis-dev)
sudo apt-get update
missing=()
for p in "${PKGS[@]}"; do
  sudo apt-get install -y "$p" >/dev/null 2>&1 && echo "ok       $p" || { echo "FAILED   $p"; missing+=("$p"); }
done
# Intel MKL is in 'multiverse' and ~1 GB; it works on AMD CPUs too.
if [ "${WITH_MKL:-0}" = "1" ]; then
  sudo DEBIAN_FRONTEND=noninteractive apt-get install -y libmkl-dev >/dev/null 2>&1 \
    && echo "ok       libmkl-dev" || { echo "FAILED   libmkl-dev"; missing+=(libmkl-dev); }
else
  echo "skipped  libmkl-dev (run with WITH_MKL=1 to include blas=Intel10_64lp)"
fi
echo
[ ${#missing[@]} -eq 0 ] && echo "All packages installed." || echo "Not installed: ${missing[*]}"
echo "AOCL (blas=AOCL_mt) and ZenDNN (GGML_ZENDNN=1) are manual installs, see README."
