# llama.cpp build-configuration benchmark on native Windows, GPU via Vulkan (target `vulkan`).
# Same protocol as the Linux `gpu` target: pinned llama.cpp commit, same model, pp512/tg128,
# 5 repetitions, all layers on the GPU. Run from PowerShell inside the hpcbench folder:
#
#   powershell -ExecutionPolicy Bypass -File .\scripts\windows_vulkan.ps1 -Setup     # llama.cpp + model, once
#   powershell -ExecutionPolicy Bypass -File .\scripts\windows_vulkan.ps1 -Test      # 2 configs, quick check
#   powershell -ExecutionPolicy Bypass -File .\scripts\windows_vulkan.ps1            # 200 distinct random configs
#   powershell -ExecutionPolicy Bypass -File .\scripts\windows_vulkan.ps1 -Status
#   powershell -ExecutionPolicy Bypass -File .\scripts\windows_vulkan.ps1 -Export    # CSV + JSON zip into .\export
#
# Options: -N 200  -Seed 1  -Data C:\hpcb  -Fix "compiler=cl"  (Ctrl+C is safe: rerun to resume)
# Needs: Visual Studio 2022 (Build Tools) with "Desktop development with C++", the Vulkan SDK, Git, Python 3.
param(
    [int]$N = 200,
    [int]$Seed = 1,
    [string]$Data = "C:\hpcb",            # short path: llama.cpp's build trees hit Windows' 260-char limit
    [string]$Fix = "",
    [switch]$Setup, [switch]$Test, [switch]$Status, [switch]$Export
)
$ErrorActionPreference = "Stop"
$Repo = Split-Path -Parent $PSScriptRoot
$Commit = "23f7aabc16c72f6f707dba227251c35d7bd1ed96"
$ModelUrl = "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf"
# sha256 of the model in the existing results (xaas-data-test); every machine must use this exact file
$ModelSha = "6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"

function Fail($msg) { Write-Host "ERROR: $msg" -ForegroundColor Red; exit 1 }

$env:HPCBENCH_HOME = $Data
$Src = Join-Path $Data "src\llama.cpp"
$Model = Join-Path $Data "models\llamacpp\model.gguf"
$Json = Join-Path $Data "json"
$Results = Join-Path $Data "results\llamacpp\$($env:COMPUTERNAME)__vulkan.jsonl"
New-Item -ItemType Directory -Force -Path $Data | Out-Null
Set-Location $Repo

if ($Status) {
    $n = if (Test-Path $Json) { (Get-ChildItem $Json -Filter *.json).Count } else { 0 }
    Write-Host "JSON files (one per configuration): $n   in $Json"
    if (Test-Path $Results) {
        Get-Content $Results | ForEach-Object { ($_ | ConvertFrom-Json).status } | Group-Object | Format-Table Count, Name -AutoSize
    }
    exit 0
}

if ($Export) {
    $out = Join-Path $Repo "export"
    New-Item -ItemType Directory -Force -Path $out | Out-Null
    python -m hpcbench export llamacpp --target vulkan --results $Results --ok-only --csv (Join-Path $out "vulkan-results.csv")
    Compress-Archive -Path (Join-Path $Json "*.json") -DestinationPath (Join-Path $out "vulkan-json.zip") -Force
    Write-Host "Exported to $out"
    exit 0
}

# --- Visual Studio compiler environment (cl, ninja, cmake), unless already in a Developer PowerShell ---
if (-not (Get-Command cl -ErrorAction SilentlyContinue)) {
    $vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
    if (-not (Test-Path $vswhere)) { Fail "Visual Studio 2022 / Build Tools not found. Install them with 'Desktop development with C++'." }
    $vs = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if (-not $vs) { Fail "Visual Studio found, but without the C++ tools. Add 'Desktop development with C++' in the Visual Studio Installer." }
    $env:PATH = "$(Split-Path $vswhere);$env:PATH"     # Launch-VsDevShell calls vswhere by name
    & (Join-Path $vs "Common7\Tools\Launch-VsDevShell.ps1") -Arch amd64 -HostArch amd64 -SkipAutomaticLocation | Out-Null
    Set-Location $Repo
}
foreach ($t in "cl", "cmake", "ninja", "git", "python") {
    if (-not (Get-Command $t -ErrorAction SilentlyContinue)) { Fail "$t not found in PATH" }
}
if (-not (Get-Command glslc -ErrorAction SilentlyContinue)) {
    Fail "glslc not found: install the Vulkan SDK (vulkan.lunarg.com), then open a NEW PowerShell window"
}
# CMake finds the Vulkan headers/library through VULKAN_SDK; a window opened before the SDK
# was installed doesn't have it yet, so take it from the system settings or from glslc's location
if (-not $env:VULKAN_SDK) {
    $env:VULKAN_SDK = [Environment]::GetEnvironmentVariable("VULKAN_SDK", "Machine")
    if (-not $env:VULKAN_SDK) { $env:VULKAN_SDK = Split-Path (Split-Path (Get-Command glslc).Source) }
}

if ($Setup) {
    if (-not (Test-Path (Join-Path $Src ".git"))) {
        git -c core.longpaths=true clone --no-checkout https://github.com/ggml-org/llama.cpp.git $Src
        if ($LASTEXITCODE -ne 0) { Fail "git clone failed" }
    }
    git -C $Src config core.longpaths true
    git -C $Src fetch --quiet origin $Commit
    git -C $Src checkout --quiet $Commit
    if ($LASTEXITCODE -ne 0) { Fail "could not check out llama.cpp $Commit" }
    Write-Host "llama.cpp at $(git -C $Src rev-parse --short HEAD)"

    New-Item -ItemType Directory -Force -Path (Split-Path $Model) | Out-Null
    if (-not (Test-Path $Model)) {
        Write-Host "Downloading the model (1.1 GB) ..."
        # --ssl-revoke-best-effort: Windows' TLS (schannel) otherwise aborts when the certificate
        # revocation server can't be reached (CRYPT_E_REVOCATION_OFFLINE); the sha256 check below still applies
        # --retry/-C -: retry dropped connections and continue the partial file instead of starting over
        curl.exe -L --fail --ssl-revoke-best-effort --retry 10 --retry-all-errors --retry-delay 3 -C - -o "$Model.part" $ModelUrl
        if ($LASTEXITCODE -ne 0) { Fail "model download failed" }
        Move-Item "$Model.part" $Model
    }
    $sha = (Get-FileHash $Model -Algorithm SHA256).Hash.ToLower()
    if ($sha -ne $ModelSha) { Fail "model sha256 $sha does not match $ModelSha - delete $Model and run -Setup again" }
    Write-Host "model OK (sha256 $sha)"
    python -m hpcbench protocol llamacpp --target vulkan
    exit 0
}

if (-not (Test-Path $Model)) { Fail "no model yet: run with -Setup first" }

$fixArgs = @(); foreach ($f in ($Fix -split " " | Where-Object { $_ })) { $fixArgs += @("--fix", $f) }
$runArgs = @()
if ($Test) {
    $N = 2
    $Results = Join-Path $Data "results\llamacpp\test__vulkan.jsonl"
    $Json = Join-Path $Data "json-test"
    $runArgs = @("--runtime", "repetitions=2")
}
$tag = if ($Fix) { "_" + (($Fix -replace "[ =]", "-")) } else { "" }
$sample = Join-Path $Data "configs\vulkan_sample_n${N}_seed${Seed}${tag}.jsonl"
New-Item -ItemType Directory -Force -Path (Split-Path $sample) | Out-Null
if (-not (Test-Path $sample)) {
    # only configurations this machine supports (CPU ISA, GPU features, installed compilers)
    python -m hpcbench sample llamacpp --target vulkan -n $N --seed $Seed --only-supported @fixArgs --out $sample
    if ($LASTEXITCODE -ne 0) { Fail "sampling failed" }
}
Write-Host "Configurations: $sample ($((Get-Content $sample).Count))"
Write-Host "Close other programs (browser, games, launchers) - the measurement records the CPU load before each run."

# storage: each build is deleted right after its run (--clean-builds), logs of successful runs too
# (--delete-logs); only the results JSONL and one JSON per configuration remain. Stops before a build
# if less than 20 GB are free (rerun to resume).
python -m hpcbench run llamacpp --target vulkan --batch $sample --results $Results --json-dir $Json `
    --clean-builds --delete-logs --min-free-gb 20 @runArgs
if ($LASTEXITCODE -ne 0) { Fail "run stopped with an error (rerun to resume)" }
Write-Host "Done. Results: $Json (one JSON per configuration) and $Results"
