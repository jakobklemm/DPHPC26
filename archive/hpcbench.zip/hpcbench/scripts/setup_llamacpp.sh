#!/usr/bin/env bash
# Fetch llama.cpp at a pinned commit and a benchmark model.
# Usage: scripts/setup_llamacpp.sh [commit]
set -euo pipefail
ROOT="${HPCBENCH_HOME:-$(cd "$(dirname "$0")/.." && pwd)}"   # data root (cluster: scratch)
COMMIT="${1:-23f7aabc16c72f6f707dba227251c35d7bd1ed96}"   # tested 2026-10-16
# Everyone in a study must use the identical model file. Put the sha256 printed on the
# first machine here (or export EXPECTED_SHA256) so every other machine is checked against it.
EXPECTED_SHA256="${EXPECTED_SHA256:-}"
MODEL_URL="${MODEL_URL:-https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf}"

SRC="${LLAMACPP_SRC:-$ROOT/src/llama.cpp}"
if [ ! -d "$SRC/.git" ]; then
  git clone https://github.com/ggml-org/llama.cpp.git "$SRC"
fi
if [ "$(git -C "$SRC" rev-parse HEAD)" != "$COMMIT" ]; then
  git -C "$SRC" fetch --quiet origin "$COMMIT" || git -C "$SRC" fetch --quiet origin
  git -C "$SRC" checkout --quiet "$COMMIT"
fi
echo "llama.cpp at $(git -C "$SRC" rev-parse --short HEAD)"

mkdir -p "$ROOT/models/llamacpp"
MODEL="$ROOT/models/llamacpp/model.gguf"
if [ ! -f "$MODEL" ]; then
  curl -L --fail -o "$MODEL.part" "$MODEL_URL" && mv "$MODEL.part" "$MODEL"
fi
SHA=$(sha256sum "$MODEL" | cut -d' ' -f1)
if [ -n "$EXPECTED_SHA256" ] && [ "$SHA" != "$EXPECTED_SHA256" ]; then
  echo "ERROR: model sha256 $SHA does not match expected $EXPECTED_SHA256" >&2
  echo "       delete $MODEL and run this script again" >&2
  exit 1
fi
echo "model sha256: $SHA"
echo "model: $MODEL ($(du -h "$MODEL" | cut -f1)) from $MODEL_URL" | tee "$ROOT/models/llamacpp/SOURCE.txt"
