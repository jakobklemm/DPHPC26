#!/bin/bash
# Runs ON THE CLUSTER (login node or inside a job). Submits the benchmark job for one GPU type.
# usage: cluster/submit.sh GPU "REMAINING_GPUS" CHAIN MODE
set -euo pipefail
CODE="$(cd "$(dirname "$0")/.." && pwd)"
source "$CODE/cluster/config.env"
source "$CODE/cluster/remote.env"             # HPCBENCH_HOME (written by remote_setup.sh)
GPU=$1; QUEUE=${2:-}; CHAIN=${3:-0}; MODE=${4:-all}

HOURS=$JOB_HOURS
[ "$GPU" = "gb10" ] && [ "$HOURS" -gt 24 ] && HOURS=24
[ "$MODE" = "smoke" ] && HOURS=2

mkdir -p "$HPCBENCH_HOME/logs/slurm"
sbatch --parsable \
  --account="$CLUSTER_ACCOUNT" \
  --gpus="$GPU:1" \
  --time="$((HOURS * 60))" \
  --job-name="hpcb-$GPU" \
  --output="$HPCBENCH_HOME/logs/slurm/%x-%j.out" \
  --export=ALL,HPCB_GPU="$GPU",HPCB_QUEUE="$QUEUE",HPCB_CHAIN="$CHAIN",HPCB_MODE="$MODE",HPCB_HOURS="$HOURS" \
  "$CODE/cluster/job.sh"
