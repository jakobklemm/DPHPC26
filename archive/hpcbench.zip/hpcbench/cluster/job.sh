#!/bin/bash --login
# Slurm job: build + benchmark llama.cpp CUDA configurations on the allocated GPU.
# Resubmits itself until every configuration for this GPU is recorded, then starts the next GPU.
set -uo pipefail
CODE=~/hpcbench
source "$CODE/cluster/config.env"
source "$CODE/cluster/remote.env"
export HPCBENCH_HOME
. /etc/profile.d/modules.sh

GPU=$HPCB_GPU; MODE=$HPCB_MODE
echo "== hpcbench job $SLURM_JOB_ID on $(hostname): gpu=$GPU mode=$MODE chain=$HPCB_CHAIN $(date)"

# --- CUDA module: newest that supports this GPU (CUDA 13 dropped Pascal, i.e. the 1080 Ti) ---
CC=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader -i 0 | tr -d ' .')
MODS=$(module -t avail cuda 2>&1 | grep -E '^cuda/[0-9]' | sort -V)
if [ "${CC:-0}" -lt 75 ]; then MODS=$(echo "$MODS" | grep -E '^cuda/(11|12)\.'); fi
MOD=$(echo "$MODS" | tail -1)
[ -n "$MOD" ] || { echo "no suitable cuda module found:"; module -t avail cuda; exit 1; }
module add "$MOD"
echo "compute capability $CC, using $MOD ($(nvcc --version | grep release))"

# --- build tools: llama.cpp needs CMake >= 3.24 for some CUDA features ---
export PATH="$HOME/.local/bin:$PATH"
cmake_ok() {
  local v; v=$(cmake --version 2>/dev/null | awk 'NR==1{print $3}')
  [ -n "$v" ] && [ "$(printf '%s\n3.24\n' "$v" | sort -V | head -1)" = "3.24" ]
}
if ! cmake_ok; then
  python3 -m pip install --user -q "cmake>=3.28" ninja
fi
command -v ninja >/dev/null || python3 -m pip install --user -q ninja

export HPCBENCH_BUILD_DIR="${TMPDIR:-/tmp}/hpcbench-builds"      # local SSD, wiped after the job
[ "$GPU" = "gb10" ] && [ -x /usr/bin/drop-caches ] && export HPCBENCH_PRE_RUN=/usr/bin/drop-caches

RESULTS="$HPCBENCH_HOME/results/llamacpp/cluster__${GPU}__cuda.jsonl"
if [ "$MODE" = "smoke" ]; then
  BATCH="$HPCBENCH_HOME/configs/cuda_default.jsonl"
  RESULTS="$HPCBENCH_HOME/results/llamacpp/smoke__${GPU}__cuda.jsonl"
else
  BATCH="$HPCBENCH_HOME/configs/cuda_all.jsonl"
fi
ARGS=(llamacpp --target cuda --batch "$BATCH" --results "$RESULTS" -j "$(nproc)" --runtime "repetitions=$REPETITIONS")

cd "$CODE"
./bench hwinfo --gpu
# stop 15 min before the wall time so the job can resubmit itself cleanly
timeout --signal=TERM $(( HPCB_HOURS * 3600 - 900 )) ./bench run "${ARGS[@]}"
echo "== run ended with $? at $(date)"

REMAINING=$(./bench run "${ARGS[@]}" --count-remaining 2>/dev/null || echo "?")
echo "== remaining configurations for $GPU: $REMAINING"

if [ "$MODE" != "smoke" ] && [ "$REMAINING" != "0" ] && [ "$REMAINING" != "?" ] && [ "$HPCB_CHAIN" -lt "$MAX_CHAIN" ]; then
  echo "== resubmitting $GPU"; "$CODE/cluster/submit.sh" "$GPU" "$HPCB_QUEUE" $((HPCB_CHAIN + 1)) "$MODE"
elif [ -n "$HPCB_QUEUE" ]; then
  NEXT=${HPCB_QUEUE%%+*}; REST=${HPCB_QUEUE#"$NEXT"}; REST=${REST#+}      # queue is "a+b+c"
  echo "== starting next GPU: $NEXT"; "$CODE/cluster/submit.sh" "$NEXT" "$REST" 0 "$MODE"
else
  echo "== all done"
fi
