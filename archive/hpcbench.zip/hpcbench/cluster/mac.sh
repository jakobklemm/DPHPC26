#!/bin/bash
# Drive the llama.cpp CUDA benchmark on the ETH student cluster from your Mac.
#
#   cluster/mac.sh push                 copy the harness to the cluster
#   cluster/mac.sh setup                clone llama.cpp, download the model, list all configs
#   cluster/mac.sh smoke GPU            one default build on one GPU type (test + build-time estimate)
#   cluster/mac.sh submit [GPU ...]     benchmark ALL configs, GPU by GPU (default: GPUS from config.env)
#   cluster/mac.sh status               queue + progress per GPU
#   cluster/mac.sh log                  tail of the newest job log
#   cluster/mac.sh pull                 export one JSON per configuration and copy everything to ./cluster-results
#   cluster/mac.sh cancel               cancel all your jobs
#   cluster/mac.sh shell                ssh into the login node
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
CFG="$HERE/cluster/config.env"
[ -f "$CFG" ] || { cp "$HERE/cluster/config.env.example" "$CFG"; echo "Created $CFG - fill in user/account, then rerun."; exit 1; }
source "$CFG"
grep -q your_eth_username "$CFG" && { echo "Edit $CFG first (CLUSTER_USER, CLUSTER_ACCOUNT)."; exit 1; }

REMOTE="$CLUSTER_USER@$CLUSTER_HOST"
mkdir -p "$HOME/.ssh"
# one ssh connection reused for all commands -> you type your password once per 30 min
SSH_OPTS=(-o ControlMaster=auto -o "ControlPath=$HOME/.ssh/hpcbench-%r@%h:%p" -o ControlPersist=30m)
rsh() { ssh "${SSH_OPTS[@]}" "$REMOTE" "$@"; }
RCODE="hpcbench"                       # ~/hpcbench on the cluster (code only)
datadir() { rsh "source ~/$RCODE/cluster/remote.env && echo \$HPCBENCH_HOME"; }

cmd=${1:-help}; shift || true
case "$cmd" in
  push)
    rsync -az --delete -e "ssh ${SSH_OPTS[*]}" \
      --exclude src/ --exclude models/ --exclude builds/ --exclude logs/ --exclude results/ \
      --exclude cluster-results/ --exclude '__pycache__/' --exclude cluster/remote.env \
      "$HERE/" "$REMOTE:$RCODE/"
    echo "pushed to $REMOTE:~/$RCODE" ;;
  setup)
    rsh "bash ~/$RCODE/cluster/remote_setup.sh" ;;
  smoke)
    GPU=${1:?usage: smoke GPU   (5060ti | 2080ti | 1080ti | gb10)}
    rsh "bash ~/$RCODE/cluster/submit.sh $GPU '' 0 smoke" | sed 's/^/submitted job /' ;;
  submit)
    LIST=("$@"); [ ${#LIST[@]} -eq 0 ] && read -r -a LIST <<< "$GPUS"
    FIRST=${LIST[0]}; REST=$(IFS=+; echo "${LIST[*]:1}")
    rsh "bash ~/$RCODE/cluster/submit.sh $FIRST '$REST' 0 all" | sed "s/^/submitted job (first GPU: $FIRST, then: ${REST:-none}) /" ;;
  status)
    rsh "squeue -u $CLUSTER_USER -o '%.10i %.14j %.8T %.10M %.10l %R'; cd ~/$RCODE && python3 cluster/progress.py" ;;
  log)
    D=$(datadir); rsh "ls -t $D/logs/slurm/*.out 2>/dev/null | head -1 | xargs -r tail -n 40" ;;
  pull)
    D=$(datadir)
    rsh "cd ~/$RCODE && HPCBENCH_HOME=$D ./bench export-json llamacpp --target cuda --out $D/json"
    mkdir -p "$HERE/cluster-results"
    rsync -az -e "ssh ${SSH_OPTS[*]}" "$REMOTE:$D/json" "$REMOTE:$D/results" "$REMOTE:$D/logs" "$HERE/cluster-results/"
    echo "-> $HERE/cluster-results/json  ($(ls "$HERE/cluster-results/json" | wc -l | tr -d ' ') files)" ;;
  cancel)
    rsh "scancel -u $CLUSTER_USER" && echo "cancelled all jobs" ;;
  shell)
    ssh "${SSH_OPTS[@]}" "$REMOTE" ;;
  *)
    sed -n '2,13p' "$0" ;;
esac
