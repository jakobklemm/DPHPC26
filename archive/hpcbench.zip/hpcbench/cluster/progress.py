"""Progress per GPU type, read from the results files (runs on the login node)."""
import json
import os
from collections import Counter
from pathlib import Path

env = dict(l.split("=", 1) for l in Path(__file__).with_name("remote.env").read_text().split() if "=" in l)
data = Path(env["HPCBENCH_HOME"])
total = sum(1 for l in (data / "configs/cuda_all.jsonl").read_text().splitlines() if l.strip())
for f in sorted((data / "results/llamacpp").glob("*__cuda.jsonl")):
    recs = [json.loads(l) for l in f.read_text().splitlines() if l.strip()]
    st = Counter(r["status"] for r in recs)
    hashes = {r["config_hash"] for r in recs if r["status"] != "skipped"}
    gpu = recs[-1]["hardware"].get("gpu_name", "?") if recs else "?"
    print(f"{f.stem:32s} {gpu:28s} {len(hashes):3d}/{total} configs  {dict(st)}")
