#!/bin/bash
# Runs ON THE LOGIN NODE (light work only: git clone, download, write config lists).
set -euo pipefail
CODE="$(cd "$(dirname "$0")/.." && pwd)"
source "$CODE/cluster/config.env"
for d in "/scratch/users/$USER" "/work/scratch/$USER" "$HOME"; do
  if [ -d "$d" ] && [ -w "$d" ]; then DATA="$d/hpcbench"; break; fi
done
mkdir -p "$DATA/configs" "$DATA/results/llamacpp" "$DATA/logs/slurm"
echo "HPCBENCH_HOME=$DATA" > "$CODE/cluster/remote.env"
echo "data directory: $DATA"
export HPCBENCH_HOME="$DATA"

"$CODE/scripts/setup_llamacpp.sh"

cd "$CODE"
./bench sample llamacpp --target cuda --all --seed 0 --out "$DATA/configs/cuda_all.jsonl"
echo '{"config": {}}' > "$DATA/configs/cuda_default.jsonl"
./bench protocol llamacpp --target cuda
