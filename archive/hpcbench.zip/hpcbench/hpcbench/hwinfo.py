"""Hardware feature extraction (the surrogate model's input side).

Everything is best-effort and never raises: missing tools just yield fewer
features. `features()` returns a flat dict of numbers/strings that can go
straight into a DataFrame.
"""
from __future__ import annotations

import os
import platform
import re
import shutil
import subprocess
from pathlib import Path

# ISA flags we care about, as named in /proc/cpuinfo
ISA_FLAGS = ["sse4_2", "avx", "avx2", "fma", "f16c", "bmi2", "avx_vnni",
             "avx512f", "avx512bw", "avx512vl", "avx512vbmi", "avx512_vnni",
             "avx512_bf16", "amx_tile", "amx_int8", "amx_bf16"]


def _sh(cmd: list[str], timeout: float = 20) -> str:
    if not shutil.which(cmd[0]):
        return ""
    try:
        # errors="replace": Windows tools print localized text (e.g. German umlauts) in other code pages
        return subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=timeout).stdout or ""
    except Exception:
        return ""


def _size_to_kib(s: str) -> float | None:
    m = re.match(r"\s*([\d.]+)\s*([KMG]i?B?)?", s)
    if not m:
        return None
    val, unit = float(m.group(1)), (m.group(2) or "K").upper()[0]
    return val * {"K": 1, "M": 1024, "G": 1024 * 1024}[unit]


def cpu_features() -> dict:
    if os.name == "nt":
        return _windows_cpu_features()
    f: dict = {"cpu_arch": platform.machine()}
    lscpu = {}
    for line in _sh(["lscpu"]).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            lscpu[k.strip()] = v.strip()
    f["cpu_model"] = lscpu.get("Model name")
    f["cpu_vendor"] = lscpu.get("Vendor ID")
    try:
        sockets = int(lscpu.get("Socket(s)", 1))
        cps = int(lscpu.get("Core(s) per socket", 0))
        tpc = int(lscpu.get("Thread(s) per core", 1))
        f["cpu_sockets"], f["cpu_cores"], f["cpu_threads"] = sockets, sockets * cps, sockets * cps * tpc
    except ValueError:
        f["cpu_threads"] = os.cpu_count()
    if not f.get("cpu_cores"):
        f["cpu_cores"] = os.cpu_count()
    for key, name in [("L1d cache", "l1d"), ("L2 cache", "l2"), ("L3 cache", "l3")]:
        if key in lscpu:
            kib = _size_to_kib(lscpu[key])  # lscpu reports the total, e.g. "32 MiB (2 instances)"
            if kib:
                f[f"cpu_{name}_kib_total"] = kib
    for key, name in [("CPU max MHz", "cpu_max_mhz"), ("CPU min MHz", "cpu_min_mhz")]:
        try:
            f[name] = float(lscpu[key])
        except (KeyError, ValueError):
            pass
    f["numa_nodes"] = int(lscpu.get("NUMA node(s)", 1) or 1)

    flags = set()
    try:
        for line in Path("/proc/cpuinfo").read_text().splitlines():
            if line.startswith("flags"):
                flags = set(line.split(":", 1)[1].split())
                break
    except OSError:
        pass
    for fl in ISA_FLAGS:
        f[f"isa_{fl}"] = int(fl in flags)

    try:
        mem = Path("/proc/meminfo").read_text()
        f["mem_total_gib"] = round(int(re.search(r"MemTotal:\s+(\d+)", mem).group(1)) / 2**20, 1)
    except Exception:
        pass
    try:
        f["cpu_governor"] = Path("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor").read_text().strip()
    except OSError:
        f["cpu_governor"] = None
    return f


def amd_gpu_features() -> dict:
    """Parse rocminfo (preferred) and rocm-smi. Returns {} if no ROCm GPU."""
    out = _sh(["rocminfo"])
    f: dict = {}
    if out:
        # rocminfo lists agents; take the first GPU agent
        for agent in re.split(r"\*{5,}\s*\nAgent \d+", out)[1:]:
            if re.search(r"Device Type:\s+GPU", agent):
                def g(pat):
                    m = re.search(pat, agent)
                    return m.group(1).strip() if m else None
                f["gpu_vendor"] = "AMD"
                f["gpu_arch"] = g(r"\n\s+Name:\s+(gfx\w+)")
                f["gpu_name"] = g(r"Marketing Name:\s+(.+)")
                for key, pat in [("gpu_compute_units", r"Compute Unit:\s+(\d+)"),
                                 ("gpu_max_clock_mhz", r"Max Clock Freq\. \(MHz\):\s+(\d+)"),
                                 ("gpu_wavefront", r"Wavefront Size:\s+(\d+)"),
                                 ("gpu_simds_per_cu", r"SIMDs per CU:\s+(\d+)")]:
                    v = g(pat)
                    if v:
                        f[key] = int(v)
                l2 = g(r"L2:\s+(\d+)\(")
                if l2:
                    f["gpu_l2_kib"] = int(l2)
                break
    smi = _sh(["rocm-smi", "--showmeminfo", "vram", "--csv"])
    m = re.search(r"VRAM Total Memory \(B\)[^\n]*\n[^,]*,(\d+)", smi)
    if m:
        f["gpu_vram_gib"] = round(int(m.group(1)) / 2**30, 1)
    ver = _sh(["hipconfig", "--version"]).strip()
    if ver:
        f["rocm_hip_version"] = ver.splitlines()[0]
    return f


def nvidia_gpu_features() -> dict:
    """nvidia-smi for clocks/power/driver, plus a tiny compiled CUDA probe for SM count,
    caches, bus width and a *measured* memory bandwidth. {} if no NVIDIA GPU."""
    f: dict = {}
    q = ("name,compute_cap,memory.total,clocks.max.sm,clocks.max.memory,power.limit,"
         "driver_version,pcie.link.gen.max,pcie.link.width.max")
    out = _sh(["nvidia-smi", f"--query-gpu={q}", "--format=csv,noheader,nounits", "-i", "0"])
    if out.strip():
        vals = [v.strip() for v in out.strip().splitlines()[0].split(",")]
        keys = ["gpu_name", "gpu_cc", "gpu_vram_mib", "gpu_max_sm_clock_mhz", "gpu_max_mem_clock_mhz",
                "gpu_power_limit_w", "nvidia_driver", "gpu_pcie_gen", "gpu_pcie_width"]
        for k, v in zip(keys, vals):
            try:
                f[k] = float(v) if k not in ("gpu_name", "gpu_cc", "nvidia_driver") else v
            except ValueError:
                f[k] = None          # "[N/A]" e.g. on integrated GPUs
        f["gpu_vendor"] = "NVIDIA"
    nvcc = shutil.which("nvcc")
    if f and nvcc:
        src = Path(__file__).parent / "probes" / "cuda_probe.cu"
        cache = Path(os.environ.get("TMPDIR", "/tmp")) / f"hpcbench_cuda_probe_{os.getuid()}"
        if not cache.exists():
            subprocess.run([nvcc, "-O2", "-o", str(cache), str(src)], capture_output=True, timeout=300)
        if cache.exists():
            import json
            try:
                f.update(json.loads(_sh([str(cache)], timeout=120) or "{}"))
            except Exception:
                pass
        ver = re.search(r"release ([\d.]+)", _sh([nvcc, "--version"]))
        if ver:
            f["cuda_toolkit_version"] = ver.group(1)
    if f.get("gpu_cc"):
        f["gpu_arch"] = "sm_" + str(f["gpu_cc"]).replace(".", "")
    return f


def vulkan_gpu_features() -> dict:
    """vulkaninfo (ships with the GPU driver): the first discrete GPU, as llama.cpp's Vulkan
    backend sees it. Used where neither rocminfo nor nvidia-smi exist, e.g. native Windows.
    {} if no Vulkan GPU."""
    out = _sh(["vulkaninfo"], timeout=60)
    blocks = re.split(r"^GPU\d+:\s*$", out, flags=re.MULTILINE)[1:]
    block = next((b for b in blocks if "PHYSICAL_DEVICE_TYPE_DISCRETE_GPU" in b), blocks[0] if blocks else "")
    if not block:
        return {}
    g = lambda key: (lambda m: m.group(1).strip() if m else None)(
        re.search(rf"^\s*{key}\s*=\s*(.+)$", block, flags=re.MULTILINE))
    vendor = {"0x1002": "AMD", "0x10de": "NVIDIA", "0x8086": "Intel"}.get((g("vendorID") or "").lower())
    f: dict = {"gpu_name": g("deviceName"), "gpu_vendor": vendor or g("vendorID"),
               "gpu_device_id": g("deviceID"), "vk_api_version": (g("apiVersion") or "").split(" ")[0] or None,
               "vk_driver_name": g("driverName"), "vk_driver": g("driverInfo")}
    heaps = re.findall(r"memoryHeaps\[\d+\]:\s*\n\s*size\s*=\s*(\d+).*?flags:(.*?)(?=memoryHeaps\[|\n\S|\Z)",
                       block, flags=re.DOTALL)
    local = [int(size) for size, flags in heaps if "DEVICE_LOCAL" in flags]
    if local:
        f["gpu_vram_gib"] = round(max(local) / 2**30, 1)
    for key, name in [("subgroupSize", "gpu_wavefront"), ("minSubgroupSize", "gpu_min_subgroup"),
                      ("maxSubgroupSize", "gpu_max_subgroup")]:
        v = g(key)
        if v and v.isdigit():
            f[name] = int(v)
    # device features llama.cpp's Vulkan backend switches on when present
    f["vk_fp16"] = int(g("shaderFloat16") == "true")
    f["vk_integer_dot_product"] = int("VK_KHR_shader_integer_dot_product" in block)
    f["vk_coopmat"] = int("VK_KHR_cooperative_matrix" in block)
    f["vk_coopmat2"] = int("VK_NV_cooperative_matrix2" in block)
    return f


def allocated_cores() -> int:
    """Cores this process may use (Slurm restricts it to 2-20 on the cluster)."""
    try:
        return len(os.sched_getaffinity(0))
    except AttributeError:
        return os.cpu_count() or 1


def gpu_arch() -> str | None:
    return amd_gpu_features().get("gpu_arch")


def toolchain() -> dict:
    t = {}
    for name in ["gcc", "clang", "cmake", "ninja"]:
        line = _sh([name, "--version"]).splitlines()
        t[f"{name}_version"] = line[0] if line else None
    t["kernel"] = platform.release()
    if os.name == "nt":
        t["kernel"] = f"Windows {platform.release()} ({platform.version()})"
        if shutil.which("cl"):      # prints its banner to stderr, only without arguments, localized,
            raw = subprocess.run(["cl"], capture_output=True).stderr      # as UTF-8 or in the console code page
            try:
                text = raw.decode("utf-8")
            except UnicodeDecodeError:
                text = raw.decode("oem", errors="replace")
            banner = text.splitlines()
            t["msvc_version"] = banner[0].strip() if banner else None
        line = _sh(["clang-cl", "--version"]).splitlines()
        t["clang_cl_version"] = line[0] if line else None
        t["vulkan_sdk"] = Path(os.environ["VULKAN_SDK"]).name if os.environ.get("VULKAN_SDK") else None
    return t


def features(include_gpu: bool = True) -> dict:
    f = {"hostname": platform.node(), "wsl": int(is_wsl()), **cpu_features(), **toolchain()}
    f["cpu_cores_allocated"] = allocated_cores()
    if os.environ.get("SLURM_JOB_ID"):
        f["slurm_node"] = os.environ.get("SLURMD_NODENAME")
    if include_gpu:
        f.update(amd_gpu_features() or nvidia_gpu_features() or vulkan_gpu_features())
    return f


def is_wsl() -> bool:
    return "microsoft" in platform.release().lower()


def _linux_busy_pct(interval: float = 1.0) -> float | None:
    """CPU utilisation of the Linux side over `interval` seconds, from /proc/stat."""
    import time

    def snap():
        v = list(map(int, Path("/proc/stat").read_text().splitlines()[0].split()[1:]))
        idle = v[3] + (v[4] if len(v) > 4 else 0)
        return sum(v), idle
    try:
        t0, i0 = snap()
        time.sleep(interval)
        t1, i1 = snap()
        return round(100.0 * (1 - (i1 - i0) / max(1, t1 - t0)), 1)
    except Exception:
        return None


def _windows_host() -> dict:
    """Under WSL, Linux can't see Windows programs. Ask Windows directly."""
    out = _sh(["powershell.exe", "-NoProfile", "-Command",
               "(Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average;"
               "(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory;"
               "powercfg /getactivescheme"], timeout=30)
    lines = [l.strip() for l in out.splitlines() if l.strip()]
    d: dict = {}
    if lines:
        try:
            d["host_cpu_load_pct"] = float(lines[0].replace(",", "."))
        except ValueError:
            pass
        if os.name == "nt" and len(lines) > 2 and lines[1].isdigit():
            d["mem_available_gib"] = round(int(lines[1]) / 2**20, 2)      # KiB
        m = re.search(r"\(([^)]+)\)\s*$", lines[-1])
        if m:
            d["host_power_plan"] = m.group(1)
    return d


def _windows_cpu_features() -> dict:
    """Native Windows has no lscpu or /proc: CIM for model, cores, caches and memory, and a tiny
    CPUID probe (compiled once with the cl / clang-cl in PATH) for the ISA flags.
    Same keys as cpu_features() on Linux; isa_* are left out if no compiler is available."""
    import json
    arch = platform.machine()
    f: dict = {"cpu_arch": "x86_64" if arch.upper() in ("AMD64", "X86_64") else arch.lower()}
    ps = ("$p = @(Get-CimInstance Win32_Processor); $c = Get-CimInstance Win32_ComputerSystem;"
          "[pscustomobject]@{name=$p[0].Name.Trim(); vendor=$p[0].Manufacturer; sockets=$p.Count;"
          "cores=($p | Measure-Object NumberOfCores -Sum).Sum;"
          "threads=($p | Measure-Object NumberOfLogicalProcessors -Sum).Sum;"
          "l2=($p | Measure-Object L2CacheSize -Sum).Sum; l3=($p | Measure-Object L3CacheSize -Sum).Sum;"
          "mhz=$p[0].MaxClockSpeed; mem=$c.TotalPhysicalMemory} | ConvertTo-Json")
    try:
        c = json.loads(_sh(["powershell.exe", "-NoProfile", "-Command", ps], timeout=30) or "{}")
    except ValueError:
        c = {}
    f["cpu_model"], f["cpu_vendor"] = c.get("name"), c.get("vendor")
    f["cpu_sockets"], f["cpu_cores"] = c.get("sockets"), c.get("cores") or os.cpu_count()
    f["cpu_threads"] = c.get("threads") or os.cpu_count()
    if c.get("l2"):
        f["cpu_l2_kib_total"] = float(c["l2"])
    if c.get("l3"):
        f["cpu_l3_kib_total"] = float(c["l3"])
    if c.get("mhz"):
        f["cpu_max_mhz"] = float(c["mhz"])
    f["numa_nodes"] = 1
    if c.get("mem"):
        f["mem_total_gib"] = round(int(c["mem"]) / 2**30, 1)
    f["cpu_governor"] = None

    probe = Path(os.environ.get("TEMP", ".")) / "hpcbench_cpuid_probe_v2.exe"     # bump when the probe changes
    if not probe.exists():
        cc = shutil.which("cl") or shutil.which("clang-cl")
        if cc:
            src = Path(__file__).parent / "probes" / "cpuid_probe.c"
            subprocess.run([cc, "/nologo", "/O2", str(src), f"/Fe{probe}", f"/Fo{probe.with_suffix('.obj')}"],
                           capture_output=True, timeout=120)
    if probe.exists():
        flags = set(_sh([str(probe)]).split())
        for fl in ISA_FLAGS:
            f[f"isa_{fl}"] = int(fl in flags)
        l1d = next((x.split("=")[1] for x in flags if x.startswith("l1d_kib=")), None)
        if l1d and f.get("cpu_cores"):
            f["cpu_l1d_kib_total"] = float(int(l1d) * f["cpu_cores"])   # one L1d per core, as lscpu's total
    return f


def load_snapshot() -> dict:
    """Machine state right before a measurement (stored with every result)."""
    d: dict = {}
    try:
        d["loadavg_1m"], d["loadavg_5m"], _ = os.getloadavg()
    except (OSError, AttributeError):     # AttributeError: no load average on Windows
        pass
    d["linux_busy_pct"] = _linux_busy_pct() if os.name != "nt" else None
    try:
        mem = Path("/proc/meminfo").read_text()
        d["mem_available_gib"] = round(int(re.search(r"MemAvailable:\s+(\d+)", mem).group(1)) / 2**20, 2)
    except Exception:
        pass
    if is_wsl() or os.name == "nt":
        d.update(_windows_host())
    return d
