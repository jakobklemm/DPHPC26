"""hpcbench command line.

  hpcbench space   APP --target T                 show parameters + vector order
  hpcbench hwinfo  [--gpu]                        show hardware features
  hpcbench protocol APP --target T                 show the fixed benchmark protocol + its id
  hpcbench sample  APP --target T -n N            write N random valid configs (JSONL)
  hpcbench run     APP --target T (--vector ... | --config FILE | --set K=V ... | --batch FILE)
  hpcbench export  APP --target T [--csv out.csv] flatten results for modelling
  hpcbench export-json APP --target T --out DIR    one JSON per measured build configuration
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import shutil
import socket
import sys
import uuid
from pathlib import Path

from . import hwinfo
from .apps import get_app, jobs_default
from .core import (HARNESS_VERSION, ROOT, append_result, config_hash, dir_bytes, git_commit,
                   load_results, now_iso, protocol_id, remove_tree, results_file)


def _kv(items: list[str]) -> dict:
    out = {}
    for it in items or []:
        if "=" not in it:
            raise SystemExit(f"expected KEY=VALUE, got {it!r}")
        k, v = it.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def _space(app, target):
    if target not in app.targets:
        raise SystemExit(f"{app.name} has targets {sorted(app.targets)}, not {target!r}")
    return app.targets[target]


# --------------------------------------------------------------------------- #
def cmd_space(a):
    app = get_app(a.app)
    sp = _space(app, a.target)
    print(f"{app.name} / {a.target}: {len(sp.params)} parameters\n")
    print(sp.describe())
    default = sp.from_dict({})
    print(f"\ndefault vector: {','.join(map(str, sp.to_vector(default)))}")


def cmd_protocol(a):
    app = get_app(a.app)
    _space(app, a.target)
    src = app.default_src()
    commit = git_commit(src)
    hw = hwinfo.features(include_gpu=False)
    rt = app.runtime_params(a.target, hw, {})
    print(f"protocol_id: {protocol_id(rt, app.PROTOCOL_KEYS, commit)}")
    print(f"  {app.name} commit: {commit}")
    for k in app.PROTOCOL_KEYS:
        print(f"  {k}: {rt.get(k)}")
    print(f"  (machine-specific, not part of the id) threads: {rt.get('threads')}, model path: {rt.get('model')}")
    print("Everyone in the study must show the same protocol_id.")


def cmd_hwinfo(a):
    print(json.dumps(hwinfo.features(include_gpu=a.gpu), indent=2))


def cmd_sample(a):
    app = get_app(a.app)
    sp = _space(app, a.target)
    hw = hwinfo.features(include_gpu=a.target != "cpu")
    fixed = sp.from_dict(_kv(a.fix)) if a.fix else None
    fixed_keys = list(_kv(a.fix)) if a.fix else []
    ok_hw = (lambda c: app.check_supported(c, a.target, hw) is None) if a.only_supported else (lambda c: True)
    # with --fix, a sampled config must keep the fixed values (after normalisation)
    valid = lambda c: ok_hw(c) and all(c[k] == fixed[k] for k in fixed_keys)
    if a.all:
        cfgs = sp.enumerate(valid=valid)
        import random
        random.Random(a.seed).shuffle(cfgs)       # any prefix of the list is a random sample
    else:
        cfgs = sp.sample(a.n, seed=a.seed, valid=valid, max_tries=200_000,
                         override={k: fixed[k] for k in fixed_keys})
    out = Path(a.out) if a.out else None
    lines = [json.dumps({"vector": sp.to_vector(c), "config": c}) for c in cfgs]
    if out:
        out.write_text("\n".join(lines) + "\n")
        print(f"wrote {len(cfgs)} configs to {out}")
    else:
        print("\n".join(lines))
    if not a.all and len(cfgs) < a.n:
        print(f"note: only {len(cfgs)} distinct valid configs found", file=sys.stderr)


def _collect_configs(a, sp) -> list[dict]:
    cfgs = []
    if a.vector:
        cfgs.append(sp.from_vector([int(x) for x in a.vector.replace(" ", "").split(",")]))
    if a.config:
        cfgs.append(sp.from_dict(json.loads(Path(a.config).read_text())))
    if a.batch:
        for line in Path(a.batch).read_text().splitlines():
            if not line.strip():
                continue
            rec = json.loads(line)
            if "config" in rec:
                cfgs.append(sp.from_dict(rec["config"]))
            elif "vector" in rec:
                cfgs.append(sp.from_vector(rec["vector"]))
            else:
                cfgs.append(sp.from_dict(rec))
    if a.set or not cfgs:
        cfgs.append(sp.from_dict(_kv(a.set)))       # defaults + overrides
    return cfgs


def _append(out_path: Path, rec: dict, json_dir: str | None) -> None:
    append_result(out_path, rec)
    if json_dir:
        write_record_json(rec, Path(json_dir))


def cmd_run(a):
    app = get_app(a.app)
    sp = _space(app, a.target)
    src = Path(a.src) if a.src else app.default_src()
    if not (src / "CMakeLists.txt").exists():
        raise SystemExit(f"source tree not found at {src} (run scripts/setup_llamacpp.sh or pass --src)")
    commit = git_commit(src)
    hw = hwinfo.features(include_gpu=a.target != "cpu")
    overrides = _kv(a.runtime)
    if a.model:
        overrides["model"] = a.model
    runtime = app.runtime_params(a.target, hw, overrides)
    proto = protocol_id(runtime, app.PROTOCOL_KEYS, commit)
    out_path = Path(a.results) if a.results else results_file(app.name, a.target)
    run_key = lambda h, rt: (h, proto, rt.get("threads"), rt.get("pin_cpus"))
    # by default every recorded outcome counts as done (also build failures), so resumed
    # jobs never loop on a config that cannot build; --retry-failed redoes non-ok ones
    # done = measured ok, or failed in a way that will fail again (build errors), or a transient
    # failure (run_failed, timeout) seen twice. "skipped" (e.g. module not loaded) is always rechecked.
    # Keeps resubmitted cluster jobs from looping forever on one broken config.
    from collections import Counter
    terminal = ("configure_failed", "build_failed", "config_not_applied", "illegal_instruction", "wrong_backend")
    attempts, done = Counter(), set()
    for r in load_results(out_path):
        k = (r["config_hash"], r.get("protocol_id"), r["runtime"].get("threads"), r["runtime"].get("pin_cpus"))
        st = r["status"]
        if st == "ok" or (not a.retry_failed and st.startswith(terminal)):
            done.add(k)
        elif st != "skipped":
            attempts[k] += 1
            if attempts[k] >= 2 and not a.retry_failed:
                done.add(k)
    ident = {"app": app.name, "target": a.target, "commit": commit}
    if a.target != "cpu":       # same config on a different GPU / toolkit is a different build
        ident.update(gpu=hw.get("gpu_name"), gpu_arch=hw.get("gpu_arch"),
                     toolkit=hw.get("cuda_toolkit_version") or hw.get("rocm_hip_version") or hw.get("vk_driver"),
                     host_arch=hw.get("cpu_arch"))

    cfgs = _collect_configs(a, sp)
    if a.count_remaining:
        print(sum(1 for c in cfgs if run_key(config_hash(c, ident), runtime) not in done))
        return
    print(f"[hpcbench] {app.name}/{a.target}: {len(cfgs)} config(s) -> {out_path}")
    print(f"[hpcbench] protocol {proto}  (llama.cpp {str(commit)[:9]}, model sha256 "
          f"{str(runtime.get('model_sha256'))[:12]}, threads {runtime.get('threads')})")
    for i, cfg in enumerate(cfgs, 1):
        h = config_hash(cfg, ident)
        tag = f"[{i}/{len(cfgs)} {h}]"
        if not a.force and run_key(h, runtime) in done:
            print(f"{tag} already measured, skipping (use --force to repeat)")
            continue

        rec = {
            "id": uuid.uuid4().hex[:16], "timestamp": now_iso(), "harness_version": HARNESS_VERSION,
            "app": app.name, "target": a.target, "host": socket.gethostname(),
            "app_commit": commit, "config_hash": h, "protocol_id": proto,
            "config": cfg, "vector": sp.to_vector(cfg), "param_order": [p.name for p in sp.params],
            "active": sp.active(cfg), "runtime": runtime, "hardware": hw,
        }
        reason = app.check_supported(cfg, a.target, hw)
        if reason:
            rec.update(status="skipped", reason=reason)
            _append(out_path, rec, a.json_dir)
            print(f"{tag} skipped: {reason}")
            continue

        build_root = Path(os.environ["HPCBENCH_BUILD_DIR"]) if os.environ.get("HPCBENCH_BUILD_DIR") else ROOT / "builds"
        # configs that differ only in run-time switches share a build (same hash as h otherwise)
        build_dir = build_root / app.name / a.target / config_hash(app.build_part(cfg, a.target), ident)
        log = ROOT / "logs" / app.name / a.target / f"{h}.log"
        rec["log"] = str(log)
        rec["cmake_args"], _ = app.cmake_args(cfg, a.target, hw)
        binary = build_dir / app.binary_rel
        free_gb = shutil.disk_usage(build_root.anchor or "/").free / 2**30
        if free_gb < a.min_free_gb:
            raise SystemExit(f"{tag} stopped: only {free_gb:.1f} GB free on {build_root.anchor or '/'} "
                             f"(--min-free-gb {a.min_free_gb:g}); free some space and rerun to resume")
        if binary.exists() and not a.rebuild:
            bstatus, btime = "cached", None
            print(f"{tag} using cached build")
        else:
            remove_tree(build_dir)
            print(f"{tag} building ...", flush=True)
            bstatus, btime, binary = app.build(cfg, a.target, src, build_dir, hw, log, a.jobs)
        rec["build"] = {"status": bstatus, "time_s": round(btime, 2) if btime else None,
                        "binary_bytes": binary.stat().st_size if binary and binary.exists() else None}
        if build_dir.exists():
            rec["build"]["dir_bytes_full"] = dir_bytes(build_dir) if bstatus == "ok" else None
        if bstatus not in ("ok", "cached"):
            rec["status"] = bstatus
            _append(out_path, rec, a.json_dir)
            remove_tree(build_dir)
            print(f"{tag} {bstatus} (see {log})")
            continue
        if bstatus == "ok" and not a.keep_build_dir:
            app.prune_build(build_dir)
        rec["build"]["dir_bytes_kept"] = dir_bytes(build_dir)

        snap = hwinfo.load_snapshot()
        busy = max([v for v in (snap.get("linux_busy_pct"), snap.get("host_cpu_load_pct")) if v is not None],
                   default=0)
        if busy > a.max_busy:
            print(f"{tag} WARNING: machine not idle before run ({busy:.0f}% CPU busy) -- "
                  f"close other programs; the measurement will be flagged")
        rec["load_before"] = snap
        rec["idle_ok"] = busy <= a.max_busy
        print(f"{tag} running ...", flush=True)
        run_env = app.run_env(cfg, a.target)
        if run_env:
            rec["run_env"] = run_env
        status, metrics, raw = app.run(binary, a.target, runtime, log, env=run_env)
        rec.update(status=status, metrics=metrics, raw=raw)
        if a.delete_logs and status == "ok":
            rec["log"] = None           # the record holds everything; logs are kept only for failures
        _append(out_path, rec, a.json_dir)
        if a.delete_logs and status == "ok":
            log.unlink(missing_ok=True)
        summary = ", ".join(f"{k}={v:.2f} (±{100 * (metrics.get(k + '_cv') or 0):.1f}%)" for k, v in metrics.items()
                            if k.endswith("_tps") and isinstance(v, (int, float)))
        print(f"{tag} {status}  {summary}")
        if a.clean_builds:
            remove_tree(build_dir)


def cmd_export(a):
    app = get_app(a.app)
    sp = _space(app, a.target)
    path = Path(a.results) if a.results else results_file(app.name, a.target)
    rows, skipped_old = [], 0
    current = [p.name for p in sp.params]
    for r in load_results(path):
        if a.ok_only and r["status"] != "ok":
            continue
        if r["param_order"] != current:
            skipped_old += 1          # recorded with an older parameter space
            continue
        row = {"id": r["id"], "timestamp": r["timestamp"], "host": r["host"], "status": r["status"],
               "config_hash": r["config_hash"], "app_commit": r["app_commit"],
               "protocol_id": r.get("protocol_id"), "idle_ok": r.get("idle_ok"),
               "threads": r["runtime"].get("threads")}
        row.update({f"cfg.{k}": v for k, v in r["config"].items()})
        row.update({f"vec.{k}": v for k, v in zip(r["param_order"], r["vector"])})
        row.update({f"hw.{k}": v for k, v in r["hardware"].items()})
        row.update({f"build.{k}": v for k, v in (r.get("build") or {}).items()})
        row.update({f"load.{k}": v for k, v in (r.get("load_before") or {}).items()})
        row.update({f"m.{k}": v for k, v in (r.get("metrics") or {}).items()
                    if not isinstance(v, (list, dict))})
        row.update({f"prof.{k}": v for k, v in ((r.get("metrics") or {}).get("cpu_profile") or {}).items()})
        rows.append(row)
    if skipped_old:
        print(f"note: skipped {skipped_old} record(s) from an older parameter space", file=sys.stderr)
    if not rows:
        raise SystemExit(f"no rows in {path}")
    cols = list(dict.fromkeys(k for row in rows for k in row))
    out = open(a.csv, "w", newline="") if a.csv else sys.stdout
    w = csv.DictWriter(out, fieldnames=cols)
    w.writeheader()
    w.writerows(rows)
    if a.csv:
        out.close()
        print(f"wrote {len(rows)} rows x {len(cols)} cols to {a.csv}")


def _slug(t: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "-", t or "unknown").strip("-").lower()


def record_to_doc(r: dict) -> dict:
    hw = r["hardware"]
    gpu = {k: v for k, v in hw.items() if k.startswith(("gpu_", "cuda_", "nvidia_", "rocm_", "vk_"))}
    host = {k: v for k, v in hw.items() if k not in gpu}
    m = r.get("metrics") or {}
    return {
        "id": r["id"], "timestamp": r["timestamp"], "status": r["status"],
        **({"reason": r.get("reason")} if r["status"] != "ok" else {}),
        "gpu": gpu,
        "host": host,
        "build_configuration": {
            "app": r["app"], "target": r["target"], "config_hash": r["config_hash"],
            "values": r["config"], "vector": r["vector"], "param_order": r["param_order"],
            "active": r.get("active"), "cmake_args": r.get("cmake_args"),
            **({"run_env": r["run_env"]} if r.get("run_env") else {}),
            "app_commit": r["app_commit"],
        },
        "performance": {
            **{k: v for k, v in m.items() if k.endswith(("_tps", "_tps_std", "_tps_cv", "_samples_tps"))},
            "unit": "tokens/s",
            "build_time_s": (r.get("build") or {}).get("time_s"),
            "llama_backends": m.get("llama_backends"),
        },
        "protocol": {"protocol_id": r.get("protocol_id"), **r["runtime"]},
        "machine_state": r.get("load_before"),
        **({"cpu_profile": m["cpu_profile"]} if m.get("cpu_profile") else {}),
    }


def write_record_json(r: dict, out: Path) -> Path:
    doc = record_to_doc(r)
    who = doc["gpu"].get("gpu_name") or doc["host"].get("cpu_model")
    name = f"{_slug(who)}__{r['target']}__{r['config_hash']}"
    if r["status"] != "ok":
        name += f"__{_slug(r['status'])}"
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{name}.json"
    path.write_text(json.dumps(doc, indent=2) + "\n")
    return path


def cmd_export_json(a):
    """One self-contained JSON per measured build configuration:
    which GPU (and host) it ran on, the build configuration, and the performance."""
    app = get_app(a.app)
    _space(app, a.target)
    paths = [Path(x) for x in a.results] if a.results else \
        sorted((ROOT / "results" / app.name).glob(f"*{a.target}*.jsonl"))
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    n = 0
    for path in paths:
        for r in load_results(path):
            if r["status"] != "ok" and not a.all_status:
                continue
            write_record_json(r, out)
            n += 1
    print(f"wrote {n} JSON file(s) to {out}")


# --------------------------------------------------------------------------- #
def main(argv=None):
    p = argparse.ArgumentParser(prog="hpcbench", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("space"); s.add_argument("app"); s.add_argument("--target", default="cpu")
    s.set_defaults(fn=cmd_space)

    s = sub.add_parser("protocol"); s.add_argument("app"); s.add_argument("--target", default="cpu")
    s.set_defaults(fn=cmd_protocol)

    s = sub.add_parser("hwinfo"); s.add_argument("--gpu", action="store_true")
    s.set_defaults(fn=cmd_hwinfo)

    s = sub.add_parser("sample"); s.add_argument("app"); s.add_argument("--target", default="cpu")
    s.add_argument("-n", type=int, default=10); s.add_argument("--seed", type=int, default=0)
    s.add_argument("--out"); s.add_argument("--only-supported", action="store_true",
                                            help="drop configs this machine cannot run")
    s.add_argument("--fix", action="append", metavar="PARAM=VALUE",
                   help="hold a parameter fixed while sampling the rest (repeatable)")
    s.add_argument("--all", action="store_true",
                   help="every distinct configuration of the space, in shuffled order (seed)")
    s.set_defaults(fn=cmd_sample)

    s = sub.add_parser("run"); s.add_argument("app"); s.add_argument("--target", default="cpu")
    s.add_argument("--vector", help="comma-separated vector, order as in `space`")
    s.add_argument("--config", help="JSON file {param: value}; missing params use defaults")
    s.add_argument("--set", action="append", metavar="PARAM=VALUE", help="override (repeatable)")
    s.add_argument("--batch", help="JSONL file from `sample` (or lines of {config}/{vector})")
    s.add_argument("--runtime", action="append", metavar="KEY=VALUE",
                   help="override fixed runtime params, e.g. repetitions=10 pin_cpus=0-7")
    s.add_argument("--model", help="GGUF model path (default models/llamacpp/model.gguf)")
    s.add_argument("--src", help="application source tree")
    s.add_argument("--results", help="results JSONL (default results/<app>/<host>__<target>.jsonl)")
    s.add_argument("-j", "--jobs", type=int, default=jobs_default())
    s.add_argument("--rebuild", action="store_true"); s.add_argument("--force", action="store_true")
    s.add_argument("--clean-builds", action="store_true", help="delete build dir (incl. binary) after each run")
    s.add_argument("--keep-build-dir", action="store_true",
                   help="keep object files etc. (default: keep only bin/ ~ a few MB per config)")
    s.add_argument("--retry-failed", action="store_true",
                   help="re-attempt configs whose build failed or that failed twice at runtime")
    s.add_argument("--json-dir", help="also write one JSON per configuration into this directory, as soon as it is measured")
    s.add_argument("--count-remaining", action="store_true",
                   help="only print how many of the given configs still need to be run, then exit")
    s.add_argument("--max-busy", type=float, default=10.0,
                   help="warn + flag the record if CPU usage before the run exceeds this %% (default 10)")
    s.add_argument("--delete-logs", action="store_true",
                   help="delete the build/run log of every successful configuration (failed ones keep theirs)")
    s.add_argument("--min-free-gb", type=float, default=0,
                   help="stop (resumable) before a build when the build drive has less free space than this")
    s.set_defaults(fn=cmd_run)

    s = sub.add_parser("export"); s.add_argument("app"); s.add_argument("--target", default="cpu")
    s.add_argument("--csv"); s.add_argument("--results"); s.add_argument("--ok-only", action="store_true")
    s.set_defaults(fn=cmd_export)

    s = sub.add_parser("export-json"); s.add_argument("app"); s.add_argument("--target", default="cpu")
    s.add_argument("--results", action="append", help="results JSONL (repeatable; default: all files of the target)")
    s.add_argument("--out", required=True, help="output directory")
    s.add_argument("--all-status", action="store_true", help="also export failed/skipped configs")
    s.set_defaults(fn=cmd_export_json)

    a = p.parse_args(argv)
    a.fn(a)


if __name__ == "__main__":
    main()
