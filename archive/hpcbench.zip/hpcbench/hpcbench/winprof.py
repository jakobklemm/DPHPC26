"""CPU profile of one benchmark process on Windows.

Windows keeps per-process counters in the kernel: CPU time (user/kernel), CPU cycles
(QueryProcessCycleTime, from the time-stamp counter), page faults, peak memory and I/O.
They are read from the process handle after the process exited, so profiling adds no
overhead and runs on the measured run itself. No driver or extra tool is needed; hardware
event counters (instructions, cache/branch misses) would need AMD uProf and are not collected.
"""
from __future__ import annotations

import ctypes
import os
import subprocess
import time
from ctypes import wintypes
from pathlib import Path


class _FILETIME(ctypes.Structure):
    _fields_ = [("lo", wintypes.DWORD), ("hi", wintypes.DWORD)]

    def seconds(self) -> float:
        return ((self.hi << 32) | self.lo) / 1e7          # 100 ns units


class _MEMORY(ctypes.Structure):      # PROCESS_MEMORY_COUNTERS
    _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]


class _IO(ctypes.Structure):          # IO_COUNTERS
    _fields_ = [(n, ctypes.c_ulonglong) for n in
                ("ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
                 "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]


def process_counters(handle: int) -> dict:
    """Counters of a (finished) process, best effort: missing ones are left out."""
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    h = wintypes.HANDLE(handle)
    byref = ctypes.byref
    p: dict = {"tool": "windows-process-counters"}
    created, exited, kernel, user = _FILETIME(), _FILETIME(), _FILETIME(), _FILETIME()
    if k32.GetProcessTimes(h, byref(created), byref(exited), byref(kernel), byref(user)):
        life = exited.seconds() - created.seconds()
        cpu = user.seconds() + kernel.seconds()
        p.update(process_lifetime_s=round(life, 3), cpu_user_s=round(user.seconds(), 3),
                 cpu_kernel_s=round(kernel.seconds(), 3), cpu_time_s=round(cpu, 3),
                 cpu_busy_threads=round(cpu / life, 3) if life > 0 else None)   # average cores in use
    cycles = ctypes.c_ulonglong()
    if k32.QueryProcessCycleTime(h, byref(cycles)):
        p["cpu_cycles"] = cycles.value
        if p.get("cpu_time_s"):
            p["cpu_effective_ghz"] = round(cycles.value / p["cpu_time_s"] / 1e9, 3)
    mem = _MEMORY()
    mem.cb = ctypes.sizeof(mem)
    if k32.K32GetProcessMemoryInfo(h, byref(mem), mem.cb):
        p.update(page_faults=mem.PageFaultCount,
                 peak_working_set_mib=round(mem.PeakWorkingSetSize / 2**20, 1),
                 peak_private_mib=round(mem.PeakPagefileUsage / 2**20, 1))
    io = _IO()
    if k32.GetProcessIoCounters(h, byref(io)):
        p.update(io_read_mib=round(io.ReadTransferCount / 2**20, 1), io_write_mib=round(io.WriteTransferCount / 2**20, 1),
                 io_read_ops=io.ReadOperationCount, io_write_ops=io.WriteOperationCount)
    return p


def run_profiled(cmd: list[str], log: Path, env: dict | None = None,
                 timeout: float | None = None) -> tuple[int, float, str, dict]:
    """Like core.run_cmd(capture=True), plus the CPU profile of the process."""
    log.parent.mkdir(parents=True, exist_ok=True)
    with open(log, "a", encoding="utf-8", errors="replace") as fh:
        fh.write(f"\n$ {' '.join(cmd)}\n")
        fh.flush()
        t0 = time.perf_counter()
        proc = subprocess.Popen(cmd, env={**os.environ, **(env or {})}, stdout=subprocess.PIPE,
                                stderr=fh, text=True, errors="replace")
        try:
            out, _ = proc.communicate(timeout=timeout)
            rc = proc.returncode
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate()
            rc, out = -999, ""
            fh.write(f"\n!! timeout after {timeout}s\n")
        secs = time.perf_counter() - t0
        profile = process_counters(int(proc._handle)) if rc != -999 else {}   # handle stays open until proc is freed
        if out:
            fh.write(out)
    return rc, secs, out or "", profile
