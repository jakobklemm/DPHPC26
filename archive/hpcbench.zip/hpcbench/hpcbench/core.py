"""Generic build-configuration space + build/run/store pipeline.

Application-specific knowledge (which CMake options exist, how to run the
benchmark, how to parse its output) lives in hpcbench/apps/<app>.py.
Everything here is app-agnostic so GROMACS, WarpX, MILC and Grid can reuse it.
"""
from __future__ import annotations

import dataclasses
import datetime as dt
import hashlib
import json
import os
import random
import shutil
import socket
import subprocess
import time
from pathlib import Path
from typing import Any, Callable

HARNESS_VERSION = "0.2.0"
ROOT = Path(os.environ.get("HPCBENCH_HOME", Path(__file__).resolve().parent.parent))


# --------------------------------------------------------------------------- #
# Configuration space
# --------------------------------------------------------------------------- #
@dataclasses.dataclass
class Param:
    """One build-time knob.

    values      -- allowed values; the vector encoding is the index into this list
                   (booleans are [0, 1], so the index equals the value).
    default     -- value used when the param is not given.
    active_if   -- predicate on the (partial) config; when False the parameter
                   has no effect and is normalised to `inactive_value` so that
                   equivalent builds get the same hash.
    """
    name: str
    values: list[Any]
    default: Any
    help: str = ""
    active_if: Callable[[dict], bool] | None = None
    inactive_value: Any = None

    def encode(self, value: Any) -> int:
        return self.values.index(value)

    def decode(self, idx: int) -> Any:
        return self.values[int(idx)]

    def coerce(self, raw: Any) -> Any:
        """Accept 'ON'/'off'/'1'/True/... for booleans and strings for choices."""
        if self.values == [0, 1]:
            if isinstance(raw, str):
                r = raw.strip().lower()
                if r in ("1", "on", "true", "yes"):
                    return 1
                if r in ("0", "off", "false", "no"):
                    return 0
                raise ValueError(f"{self.name}: cannot parse boolean {raw!r}")
            return int(bool(raw))
        for v in self.values:
            if str(v).lower() == str(raw).lower():
                return v
        raise ValueError(f"{self.name}: {raw!r} not in {self.values}")


class ConfigSpace:
    def __init__(self, params: list[Param]):
        self.params = params
        self.by_name = {p.name: p for p in params}

    # -- construction -------------------------------------------------------
    def from_dict(self, d: dict) -> dict:
        unknown = set(d) - set(self.by_name)
        if unknown:
            raise ValueError(f"unknown parameter(s): {sorted(unknown)}")
        cfg = {p.name: p.default for p in self.params}
        for k, v in d.items():
            cfg[k] = self.by_name[k].coerce(v)
        return self.normalize(cfg)

    def from_vector(self, vec: list[int]) -> dict:
        if len(vec) != len(self.params):
            raise ValueError(f"vector has {len(vec)} entries, space has {len(self.params)}: "
                             f"{[p.name for p in self.params]}")
        return self.normalize({p.name: p.decode(i) for p, i in zip(self.params, vec)})

    def normalize(self, cfg: dict) -> dict:
        out = dict(cfg)
        # iterate until fixed point (activation can be chained)
        for _ in range(len(self.params)):
            changed = False
            for p in self.params:
                if p.active_if and not p.active_if(out):
                    target = p.inactive_value if p.inactive_value is not None else p.values[0]
                    if out[p.name] != target:
                        out[p.name] = target
                        changed = True
            if not changed:
                break
        return out

    def to_vector(self, cfg: dict) -> list[int]:
        return [p.encode(cfg[p.name]) for p in self.params]

    def active(self, cfg: dict) -> dict:
        return {p.name: (p.active_if(cfg) if p.active_if else True) for p in self.params}

    def sample(self, n: int, seed: int = 0, unique: bool = True,
               valid: Callable[[dict], bool] | None = None, max_tries: int = 100_000,
               override: dict | None = None) -> list[dict]:
        rng = random.Random(seed)
        seen, out = set(), []
        for _ in range(max_tries):
            if len(out) >= n:
                break
            raw = {p.name: rng.choice(p.values) for p in self.params}
            raw.update(override or {})
            cfg = self.normalize(raw)
            if valid and not valid(cfg):
                continue
            h = config_hash(cfg)
            if unique and h in seen:
                continue
            seen.add(h)
            out.append(cfg)
        return out

    def enumerate(self, valid: Callable[[dict], bool] | None = None, limit: int = 2_000_000) -> list[dict]:
        """All distinct (normalised) configurations, walking only active branches."""
        import itertools
        seen, out = set(), []
        for n, combo in enumerate(itertools.product(*[p.values for p in self.params])):
            if n >= limit:
                raise SystemExit(f"space has more than {limit} raw combinations; use `sample -n` instead")
            cfg = self.normalize(dict(zip([p.name for p in self.params], combo)))
            h = config_hash(cfg)
            if h in seen or (valid and not valid(cfg)):
                continue
            seen.add(h)
            out.append(cfg)
        return out

    def describe(self) -> str:
        lines = [f"{'idx':>3}  {'parameter':<24} {'values (vector index = position)':<34} default"]
        for i, p in enumerate(self.params):
            cond = "  [conditional]" if p.active_if else ""
            lines.append(f"{i:>3}  {p.name:<24} {str(p.values):<34} {p.default!s:<8}{cond}")
            if p.help:
                lines.append(f"     {'':<24} {p.help}")
        return "\n".join(lines)


def config_hash(cfg: dict, extra: dict | None = None) -> str:
    blob = json.dumps({"cfg": cfg, "extra": extra or {}}, sort_keys=True)
    return hashlib.sha1(blob.encode()).hexdigest()[:12]


# --------------------------------------------------------------------------- #
# Process helpers
# --------------------------------------------------------------------------- #
def run_cmd(cmd: list[str], log: Path, cwd: Path | None = None, env: dict | None = None,
            timeout: float | None = None, capture: bool = False) -> tuple[int, float, str]:
    """Run a command, append stdout/stderr to `log`, return (rc, seconds, stdout)."""
    log.parent.mkdir(parents=True, exist_ok=True)
    full_env = {**os.environ, **(env or {})}
    t0 = time.perf_counter()
    with open(log, "a", encoding="utf-8", errors="replace") as fh:
        fh.write(f"\n$ {' '.join(cmd)}\n")
        fh.flush()
        try:
            p = subprocess.run(cmd, cwd=cwd, env=full_env, timeout=timeout,
                               stdout=subprocess.PIPE if capture else fh,
                               stderr=fh, text=True, errors="replace")
            rc, out = p.returncode, (p.stdout or "")
        except subprocess.TimeoutExpired:
            rc, out = -999, ""
            fh.write(f"\n!! timeout after {timeout}s\n")
        if capture and out:
            fh.write(out)
    return rc, time.perf_counter() - t0, out


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def git_commit(src: Path) -> str | None:
    try:
        return subprocess.check_output(["git", "-C", str(src), "rev-parse", "HEAD"],
                                       text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        return None


# --------------------------------------------------------------------------- #
# Results store (one JSON object per line -- append-only, crash-safe)
# --------------------------------------------------------------------------- #
def results_file(app: str, target: str, host: str | None = None) -> Path:
    host = host or socket.gethostname()
    return ROOT / "results" / app / f"{host}__{target}.jsonl"


def append_result(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a") as fh:
        fh.write(json.dumps(record, sort_keys=True) + "\n")


def load_results(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return [json.loads(l) for l in path.read_text().splitlines() if l.strip()]


def remove_tree(p: Path) -> None:
    shutil.rmtree(p, ignore_errors=True)


def dir_bytes(p: Path) -> int:
    return sum(f.stat().st_size for f in p.rglob("*") if f.is_file() and not f.is_symlink())


def protocol_id(runtime: dict, keys: list[str], app_commit: str | None) -> str:
    """Fingerprint of everything that must match across machines for comparable results."""
    return config_hash({k: runtime.get(k) for k in keys}, {"app_commit": app_commit})
