// Prints the properties of GPU 0 as JSON, plus a measured device-memory bandwidth.
// Compiled on the fly by hwinfo.py (nvcc -O2 -o probe cuda_probe.cu).
#include <cstdio>
#include <cuda_runtime.h>

static int attr(cudaDeviceAttr a) {
    int v = -1;
    cudaDeviceGetAttribute(&v, a, 0);
    return v;
}

int main() {
    int n = 0;
    if (cudaGetDeviceCount(&n) != cudaSuccess || n == 0) {
        printf("{}\n");
        return 1;
    }
    cudaDeviceProp p;
    cudaGetDeviceProperties(&p, 0);
    size_t free_b = 0, total_b = 0;
    cudaMemGetInfo(&free_b, &total_b);

    // measured bandwidth: device-to-device copy of 512 MiB (each byte read once + written once)
    double bw_gbs = -1;
    size_t bytes = (size_t)512 << 20;
    void *a = nullptr, *b = nullptr;
    if (cudaMalloc(&a, bytes) == cudaSuccess && cudaMalloc(&b, bytes) == cudaSuccess) {
        cudaMemset(a, 1, bytes);
        cudaEvent_t t0, t1;
        cudaEventCreate(&t0);
        cudaEventCreate(&t1);
        cudaMemcpy(b, a, bytes, cudaMemcpyDeviceToDevice);   // warm-up
        const int reps = 10;
        cudaEventRecord(t0);
        for (int i = 0; i < reps; i++) cudaMemcpy(b, a, bytes, cudaMemcpyDeviceToDevice);
        cudaEventRecord(t1);
        cudaEventSynchronize(t1);
        float ms = 0;
        cudaEventElapsedTime(&ms, t0, t1);
        bw_gbs = 2.0 * bytes * reps / (ms / 1e3) / 1e9;
    }
    if (a) cudaFree(a);
    if (b) cudaFree(b);

    int rt = 0, drv = 0;
    cudaRuntimeGetVersion(&rt);
    cudaDriverGetVersion(&drv);

    printf("{\"gpu_vendor\": \"NVIDIA\", \"gpu_name\": \"%s\", \"gpu_cc\": \"%d.%d\", "
           "\"gpu_sm_count\": %d, \"gpu_vram_gib\": %.1f, \"gpu_l2_kib\": %d, "
           "\"gpu_mem_bus_width_bits\": %d, \"gpu_max_threads_per_sm\": %d, "
           "\"gpu_regs_per_sm\": %d, \"gpu_smem_per_sm_kib\": %d, \"gpu_integrated\": %d, "
           "\"gpu_concurrent_managed_access\": %d, ",
           p.name, p.major, p.minor, p.multiProcessorCount, total_b / 1073741824.0, p.l2CacheSize / 1024,
           attr(cudaDevAttrGlobalMemoryBusWidth), attr(cudaDevAttrMaxThreadsPerMultiProcessor),
           attr(cudaDevAttrMaxRegistersPerMultiprocessor),
           attr(cudaDevAttrMaxSharedMemoryPerMultiprocessor) / 1024, attr(cudaDevAttrIntegrated),
           attr(cudaDevAttrConcurrentManagedAccess));
#if CUDART_VERSION < 13000
    printf("\"gpu_sm_clock_mhz\": %d, \"gpu_mem_clock_mhz\": %d, ",
           attr(cudaDevAttrClockRate) / 1000, attr(cudaDevAttrMemoryClockRate) / 1000);
#endif
    printf("\"gpu_measured_bw_gbs\": %.1f, \"cuda_runtime_version\": %d, \"cuda_driver_version\": %d}\n",
           bw_gbs, rt, drv);
    return 0;
}
