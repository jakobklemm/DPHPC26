/* CPU ISA flags via CPUID, for Windows (no /proc/cpuinfo there).
 * Prints the flags that are present, named as in Linux /proc/cpuinfo, one line,
 * space separated. AVX / AVX-512 only count if the OS saves their registers (XGETBV).
 * Build: cl /nologo /O2 cpuid_probe.c   (MSVC or clang-cl) */
#include <stdio.h>
#include <intrin.h>

#define BIT(r, n) (((unsigned)(r) >> (n)) & 1u)

int main(void) {
    int r[4];
    __cpuid(r, 0);
    int max_leaf = r[0];
    __cpuid(r, 1);
    int ecx1 = r[2];
    int ebx7 = 0, ecx7 = 0, edx7 = 0, eax71 = 0;
    if (max_leaf >= 7) {
        __cpuidex(r, 7, 0); ebx7 = r[1]; ecx7 = r[2]; edx7 = r[3];
        __cpuidex(r, 7, 1); eax71 = r[0];
    }
    unsigned long long xcr0 = BIT(ecx1, 27) ? _xgetbv(0) : 0;   /* OSXSAVE */
    int os_avx = (xcr0 & 0x6) == 0x6;
    int os_avx512 = os_avx && (xcr0 & 0xe0) == 0xe0;
    int os_amx = (xcr0 & 0x60000) == 0x60000;

    struct { const char *name; int on; } f[] = {
        {"sse4_2", BIT(ecx1, 20)},
        {"avx", os_avx && BIT(ecx1, 28)},
        {"fma", os_avx && BIT(ecx1, 12)},
        {"f16c", os_avx && BIT(ecx1, 29)},
        {"avx2", os_avx && BIT(ebx7, 5)},
        {"bmi2", BIT(ebx7, 8)},
        {"avx_vnni", os_avx && BIT(eax71, 4)},
        {"avx512f", os_avx512 && BIT(ebx7, 16)},
        {"avx512bw", os_avx512 && BIT(ebx7, 30)},
        {"avx512vl", os_avx512 && BIT(ebx7, 31)},
        {"avx512vbmi", os_avx512 && BIT(ecx7, 1)},
        {"avx512_vnni", os_avx512 && BIT(ecx7, 11)},
        {"avx512_bf16", os_avx512 && BIT(eax71, 5)},
        {"amx_tile", os_amx && BIT(edx7, 24)},
        {"amx_int8", os_amx && BIT(edx7, 25)},
        {"amx_bf16", os_amx && BIT(edx7, 22)},
    };
    for (unsigned i = 0; i < sizeof f / sizeof f[0]; i++)
        if (f[i].on) printf("%s ", f[i].name);

    /* L1 data cache per core: deterministic cache parameters, leaf 4 (Intel) / 0x8000001D (AMD),
     * same layout in both. Printed as l1d_kib=<n>. */
    __cpuid(r, 0x80000000);
    unsigned leaf = (r[0] >= 0x8000001D && r[2] == 0x444d4163 /* "cAMD" */) ? 0x8000001D : 4;
    for (int sub = 0; sub < 16; sub++) {
        __cpuidex(r, leaf, sub);
        int type = r[0] & 0x1f, level = (r[0] >> 5) & 0x7;
        if (type == 0) break;
        if (type == 1 && level == 1) {          /* data cache, level 1 */
            unsigned ways = ((unsigned)r[1] >> 22) + 1, parts = (((unsigned)r[1] >> 12) & 0x3ff) + 1;
            unsigned line = ((unsigned)r[1] & 0xfff) + 1, sets = (unsigned)r[2] + 1;
            printf("l1d_kib=%u ", ways * parts * line * sets / 1024);
            break;
        }
    }
    printf("\n");
    return 0;
}
