"""Build-configuration benchmark harness for HPC applications."""
