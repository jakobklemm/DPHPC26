"""llama.cpp adapter.

Two targets, each with its own build-configuration space:

  cpu  -- CPU-only build (no GPU backend compiled in), run with -ngl 0
  gpu  -- AMD GPU build, backend HIP/ROCm or Vulkan, all layers offloaded (-ngl 99)
  cuda -- NVIDIA GPU build (cluster), all layers offloaded
  vulkan -- Vulkan build on native Windows (MSVC / clang-cl), all layers offloaded; same protocol as gpu

Only *build-time* knobs are varied. The benchmark protocol (model file, prompt /
generation lengths, repetitions, batch sizes, flash-attention mode) is fixed and
fingerprinted, so results from different machines are comparable.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

from ..core import ROOT, ConfigSpace, Param, run_cmd
from . import CMakeApp

B = [0, 1]

# --- activation predicates ---------------------------------------------------
SINGLE = lambda c: c["cpu_variants"] == "single"                 # one CPU backend, chosen at build time
FLAGS = lambda c: SINGLE(c) and c["GGML_NATIVE"] == 0            # explicit ISA flags in effect
AVX512 = lambda c: FLAGS(c) and c["GGML_AVX512"] == 1
AMX = lambda c: FLAGS(c) and c["GGML_AVX512"] == 1               # ggml's AMX path needs AVX-512

# param name -> /proc/cpuinfo flag the resulting binary will require
ISA_REQUIRES = {
    "GGML_SSE42": "sse4_2", "GGML_AVX": "avx", "GGML_AVX2": "avx2", "GGML_FMA": "fma",
    "GGML_F16C": "f16c", "GGML_BMI2": "bmi2", "GGML_AVX_VNNI": "avx_vnni",
    "GGML_AVX512": "avx512f", "GGML_AVX512_VBMI": "avx512vbmi",
    "GGML_AVX512_VNNI": "avx512_vnni", "GGML_AVX512_BF16": "avx512_bf16",
    "GGML_AMX_TILE": "amx_tile", "GGML_AMX_INT8": "amx_int8", "GGML_AMX_BF16": "amx_bf16",
}

COMPILERS = ["gcc-13", "gcc-12", "gcc-14", "clang-18", "clang-17", "clang-19"]
BLAS = ["none", "OpenBLAS", "FLAME", "Intel10_64lp", "AOCL_mt"]
BLAS_LIB = {"OpenBLAS": "libopenblas", "FLAME": "libblis", "Intel10_64lp": "libmkl_rt"}


def _cpu_params() -> list[Param]:
    return [
        # -- toolchain / code generation --
        Param("compiler", COMPILERS, "gcc-13", "C/C++ compiler + version (OpenMP runtime follows: libgomp / libomp)"),
        Param("opt_level", ["O3", "O2", "O1", "Os"], "O3", "CMAKE_{C,CXX}_FLAGS_RELEASE"),
        Param("fast_math", B, 0, "-ffast-math -fno-finite-math-only (ggml needs inf/nan; speed only, correctness not checked)"),
        Param("unroll_loops", B, 0, "-funroll-loops"),
        Param("lto", B, 0, "GGML_LTO: link-time optimisation"),
        Param("shared_libs", B, 0, "BUILD_SHARED_LIBS (PIC code, calls across .so boundaries)",
              active_if=SINGLE, inactive_value=1),
        # -- ISA selection --
        Param("cpu_variants", ["single", "all"], "single",
              "all = GGML_CPU_ALL_VARIANTS + GGML_BACKEND_DL: build every x86 variant, pick at runtime"),
        Param("GGML_NATIVE", B, 1, "-march=native; when 1 the ISA flags below are ignored", active_if=SINGLE),
        Param("mtune", ["none", "generic", "native"], "none", "-mtune=... on top of explicit ISA flags",
              active_if=FLAGS),
        Param("GGML_SSE42", B, 1, active_if=FLAGS),
        Param("GGML_AVX", B, 1, active_if=FLAGS),
        Param("GGML_AVX2", B, 1, active_if=FLAGS),
        Param("GGML_FMA", B, 1, active_if=FLAGS),
        Param("GGML_F16C", B, 1, active_if=FLAGS),
        Param("GGML_BMI2", B, 1, active_if=FLAGS),
        Param("GGML_AVX_VNNI", B, 0, active_if=FLAGS),
        Param("GGML_AVX512", B, 0, active_if=FLAGS),
        Param("GGML_AVX512_VBMI", B, 0, active_if=AVX512),
        Param("GGML_AVX512_VNNI", B, 0, active_if=AVX512),
        Param("GGML_AVX512_BF16", B, 0, active_if=AVX512),
        Param("GGML_AMX_TILE", B, 0, active_if=AMX),
        Param("GGML_AMX_INT8", B, 0, active_if=AMX),
        Param("GGML_AMX_BF16", B, 0, active_if=AMX),
        # -- ggml implementation choices --
        Param("GGML_OPENMP", B, 1, "OpenMP threadpool vs ggml's own"),
        Param("GGML_LLAMAFILE", B, 1, "llamafile sgemm kernels"),
        Param("GGML_CPU_REPACK", B, 1, "runtime weight repacking into interleaved layouts"),
        Param("blas", BLAS, "none", "GGML_BLAS + GGML_BLAS_VENDOR (FLAME = BLIS, Intel10_64lp = MKL, AOCL_mt = AMD AOCL)"),
        Param("GGML_ZENDNN", B, 0, "AMD ZenDNN backend for matmuls (needs prebuilt ZenDNN, env ZENDNN_ROOT)"),
    ]


HIP = lambda c: c["backend"] == "hip"


def _gpu_params() -> list[Param]:
    return [
        Param("backend", ["hip", "vulkan"], "hip", "GPU backend compiled in"),
        Param("GGML_HIP_GRAPHS", B, 1, active_if=HIP),
        Param("GGML_HIP_NO_VMM", B, 1, active_if=HIP),
        Param("GGML_HIP_MMQ_MFMA", B, 1, "MFMA MMQ kernels (only affects CDNA / Instinct GPUs)", active_if=HIP),
        Param("GGML_CUDA_FA", B, 1, "compile flash-attention kernels", active_if=HIP),
        Param("GGML_CUDA_FA_ALL_QUANTS", B, 0, "FA kernels for all KV-cache quant types",
              active_if=lambda c: HIP(c) and c["GGML_CUDA_FA"] == 1),
        Param("mmq_mode", ["auto", "force_mmq", "force_blas"], "auto",
              "GGML_CUDA_FORCE_MMQ / GGML_CUDA_FORCE_CUBLAS (hipBLAS)", active_if=HIP),
        Param("hip_opt_level", ["O3", "O2", "O1"], "O3", "CMAKE_HIP_FLAGS_RELEASE", active_if=HIP),
        Param("hip_unsafe_fp_atomics", B, 0, "-munsafe-fp-atomics", active_if=HIP),
    ]


def _cuda_params() -> list[Param]:
    return [
        Param("gpu_target", ["exact", "generic"], "exact",
              "exact = machine code for this GPU (sm_XX-real); generic = PTX only, JIT-compiled by the driver"),
        Param("GGML_CUDA_GRAPHS", B, 1, "CUDA graphs: record kernel sequences once, replay them"),
        Param("GGML_CUDA_FA", B, 1, "compile flash-attention kernels (without them -fa auto falls back to plain attention)"),
        Param("quant_matmul", ["auto", "force_mmq", "force_cublas"], "auto",
              "quantised matmul: llama.cpp decides / always own MMQ kernels / always cuBLAS"),
        Param("GGML_CUDA_NO_VMM", B, 0, "disable CUDA virtual memory management for the memory pool"),
        Param("ptxas_opt", ["O3", "O2"], "O3", "device-code optimisation level (-Xptxas -O<n>)",
              active_if=lambda c: c["gpu_target"] == "exact"),   # PTX-only builds run no ptxas at build time
    ]


# --- vulkan target: native Windows (MSVC / clang-cl), e.g. an AMD GPU that ROCm doesn't support there ---
NOT_NATIVE = lambda c: c["isa"] != "native"
ISA_LEVEL = {"native": 0, "sse42": 1, "avx": 2, "avx2": 3}
ISA_NEEDS = {"sse42": ["sse4_2"], "avx": ["avx"], "avx2": ["avx2", "fma", "f16c"]}   # what MSVC's /arch:X uses
# The Vulkan backend has no performance-relevant CMake options (only debug ones): which GPU code paths
# it takes is decided per device at startup, and can be switched off by environment variables.
# param -> (variable set when the param is 0, device feature the path needs or None)
VK_ENV = {
    "vk_fp16": ("GGML_VK_DISABLE_F16", "vk_fp16"),
    "vk_integer_dot": ("GGML_VK_DISABLE_INTEGER_DOT_PRODUCT", "vk_integer_dot_product"),
    "vk_coopmat": ("GGML_VK_DISABLE_COOPMAT", "vk_coopmat"),
    "vk_fusion": ("GGML_VK_DISABLE_FUSION", None),
    "vk_graph_optimize": ("GGML_VK_DISABLE_GRAPH_OPTIMIZE", None),
}


def _vulkan_params() -> list[Param]:
    return [
        # -- host side: everything around the GPU kernels (graph building, scheduling, sampling) --
        Param("compiler", ["cl", "clang-cl"], "cl", "MSVC or LLVM clang-cl (VS component 'C++ Clang Compiler for Windows')"),
        Param("opt_level", ["O2", "O1", "Ox"], "O2", "CMAKE_{C,CXX}_FLAGS_RELEASE: /O2 speed, /O1 size, /Ox"),
        Param("lto", B, 0, "GGML_LTO (MSVC /GL + /LTCG; clang-cl -flto + lld-link)"),
        Param("shared_libs", B, 0, "BUILD_SHARED_LIBS: ggml and llama as DLLs"),
        Param("isa", ["native", "avx2", "avx", "sse42"], "native",
              "native = GGML_NATIVE (probe this CPU at configure time); else /arch:<isa>"),
        Param("GGML_BMI2", B, 1, active_if=lambda c: c["isa"] == "avx2"),
        Param("GGML_OPENMP", B, 1, "OpenMP threadpool vs ggml's own"),
        Param("GGML_LLAMAFILE", B, 1, "llamafile sgemm kernels"),
        Param("GGML_CPU_REPACK", B, 1, "runtime weight repacking into interleaved layouts"),
        # -- GPU side: Vulkan kernel paths, set through GGML_VK_* environment variables at run time --
        Param("vk_fp16", B, 1, "fp16 arithmetic in shaders (0 = GGML_VK_DISABLE_F16)"),
        Param("vk_integer_dot", B, 1, "int8 dot-product shaders for quantised matmul (0 = GGML_VK_DISABLE_INTEGER_DOT_PRODUCT)"),
        Param("vk_mmvq", ["auto", "force", "off"], "auto",
              "quantised mat-vec via integer dot: llama.cpp decides / GGML_VK_FORCE_MMVQ / GGML_VK_DISABLE_MMVQ",
              active_if=lambda c: c["vk_integer_dot"] == 1),
        Param("vk_coopmat", B, 1, "cooperative-matrix matmul shaders (0 = GGML_VK_DISABLE_COOPMAT)"),
        Param("vk_fusion", B, 1, "fused ops (0 = GGML_VK_DISABLE_FUSION)"),
        Param("vk_graph_optimize", B, 1, "graph reordering for fewer barriers (0 = GGML_VK_DISABLE_GRAPH_OPTIMIZE)"),
    ]


def _cc_num(hw: dict) -> str:
    return str(hw.get("gpu_cc", "")).replace(".", "")


def _ver(s) -> tuple:
    try:
        return tuple(int(x) for x in str(s).split(".")[:2])
    except ValueError:
        return (0, 0)


def _on(v) -> str:
    return "ON" if v else "OFF"


def _cxx_for(cc: str) -> str:
    return cc.replace("gcc", "g++").replace("clang", "clang++")


def _have_lib(name: str) -> bool:
    out = subprocess.run(["ldconfig", "-p"], capture_output=True, text=True).stdout
    return name in out


def sha256_cached(path: Path) -> str:
    """sha256 of a (large) file, cached next to it keyed on size+mtime."""
    st = path.stat()
    cache = path.with_suffix(path.suffix + ".sha256")
    key = f"{st.st_size}:{int(st.st_mtime)}"
    if cache.exists():
        k, _, h = cache.read_text().strip().partition(" ")
        if k == key:
            return h
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    digest = h.hexdigest()
    try:
        cache.write_text(f"{key} {digest}\n")
    except OSError:
        pass
    return digest


class LlamaCpp(CMakeApp):
    name = "llamacpp"
    build_target = "llama-bench"
    binary_rel = "bin/llama-bench" + (".exe" if os.name == "nt" else "")
    targets = {"cpu": ConfigSpace(_cpu_params()), "gpu": ConfigSpace(_gpu_params()),
               "cuda": ConfigSpace(_cuda_params()), "vulkan": ConfigSpace(_vulkan_params())}

    def build_part(self, cfg, target):
        # vk_* are run-time switches: configs that differ only in them share one build
        return {k: v for k, v in cfg.items() if not k.startswith("vk_")} if target == "vulkan" else cfg

    def run_env(self, cfg, target):
        if target != "vulkan":
            return {}
        env = {var: "1" for name, (var, _) in VK_ENV.items() if cfg[name] == 0}
        if cfg["vk_mmvq"] == "force":
            env["GGML_VK_FORCE_MMVQ"] = "1"
        elif cfg["vk_mmvq"] == "off":
            env["GGML_VK_DISABLE_MMVQ"] = "1"
        return env

    def default_src(self) -> Path:
        return Path(os.environ.get("LLAMACPP_SRC", ROOT / "src" / "llama.cpp"))

    def default_model(self) -> Path:
        return Path(os.environ.get("LLAMACPP_MODEL", ROOT / "models" / "llamacpp" / "model.gguf"))

    # ------------------------------------------------------------------ #
    def check_supported(self, cfg, target, hw):
        if target == "cpu":
            if hw.get("cpu_arch") != "x86_64":
                return "unsupported_arch:cpu space is x86-only for now"
            if FLAGS(cfg):
                missing = [ISA_REQUIRES[k] for k in ISA_REQUIRES
                           if cfg[k] == 1 and hw.get(f"isa_{ISA_REQUIRES[k]}") == 0]
                if missing:
                    return f"unsupported_isa:{','.join(missing)}"
            cc = cfg["compiler"]
            if not (shutil.which(cc) and shutil.which(_cxx_for(cc))):
                return f"missing_dependency:{cc}"
            if cc.startswith("clang") and cfg["GGML_OPENMP"]:
                ver = cc.split("-")[1]
                if not list(Path(f"/usr/lib/llvm-{ver}/lib").glob("libomp.so*")):
                    return f"missing_dependency:libomp-{ver}-dev"
            if cfg["lto"] and cc.startswith("clang"):
                v = cc.split("-")[1]
                if not (shutil.which(f"ld.lld-{v}") and shutil.which(f"llvm-ar-{v}")):
                    return f"missing_dependency:lld-{v},llvm-{v}"
            if cfg["blas"] in BLAS_LIB and not _have_lib(BLAS_LIB[cfg["blas"]]):
                return f"missing_dependency:{BLAS_LIB[cfg['blas']]}"
            if cfg["blas"] == "AOCL_mt" and not os.environ.get("AOCL_ROOT"):
                return "missing_dependency:AOCL (set AOCL_ROOT)"
            if cfg["GGML_ZENDNN"] and not os.environ.get("ZENDNN_ROOT"):
                return "missing_dependency:ZenDNN (set ZENDNN_ROOT)"
        elif target == "cuda":
            if not shutil.which("nvcc"):
                return "missing_dependency:nvcc (module add cuda/...)"
            cc = _cc_num(hw)
            if not cc:
                return "no_nvidia_gpu_detected"
            tk = _ver(hw.get("cuda_toolkit_version"))
            if int(cc) < 75 and tk >= (13, 0):
                return f"unsupported_toolkit:sm_{cc} needs CUDA < 13"
            if int(cc) >= 120 and tk < (12, 8):
                return f"unsupported_toolkit:sm_{cc} needs CUDA >= 12.8"
            if int(cc) >= 121 and tk < (12, 9):
                return f"unsupported_toolkit:sm_{cc} needs CUDA >= 12.9"
        elif target == "vulkan":
            if os.name != "nt":
                return "unsupported_os:vulkan target is for native Windows (on Linux use --target gpu)"
            for exe, why in [("cl", "MSVC (run from 'Developer PowerShell for VS')"), ("ninja", "ninja (VS CMake tools)"),
                             ("glslc", "glslc (Vulkan SDK)"), (cfg["compiler"], cfg["compiler"])]:
                if not shutil.which(exe):
                    return f"missing_dependency:{why}"
            if cfg["lto"] and cfg["compiler"] == "clang-cl" and not (shutil.which("lld-link") and shutil.which("llvm-lib")):
                return "missing_dependency:lld-link,llvm-lib"
            if not hw.get("gpu_name"):
                return "no_vulkan_gpu_detected"
            if NOT_NATIVE(cfg):
                if "isa_avx" not in hw:
                    return "missing_dependency:cpuid probe (cl not in PATH)"
                needs = ISA_NEEDS[cfg["isa"]] + (["bmi2"] if cfg["GGML_BMI2"] else [])
                missing = [n for n in needs if hw.get(f"isa_{n}") != 1]
                if missing:
                    return f"unsupported_isa:{','.join(missing)}"
            for name, (_, feature) in VK_ENV.items():
                if feature and cfg[name] == 1 and not hw.get(feature):
                    return f"unsupported_gpu_feature:{feature}"     # 1 would be the same build as 0
        else:
            if cfg["backend"] == "hip":
                if not shutil.which("hipconfig"):
                    return "missing_dependency:rocm(hipconfig)"
                if not (os.environ.get("LLAMACPP_GPU_TARGETS") or hw.get("gpu_arch")):
                    return "no_amd_gpu_detected"
            if cfg["backend"] == "vulkan" and not shutil.which("glslc"):
                return "missing_dependency:glslc(vulkan-sdk)"
        return None

    # ------------------------------------------------------------------ #
    def cmake_args(self, cfg, target, hw):
        common = [
            "-DCMAKE_BUILD_TYPE=Release",
            "-DLLAMA_BUILD_TESTS=OFF", "-DLLAMA_BUILD_EXAMPLES=OFF",
            "-DLLAMA_BUILD_SERVER=OFF", "-DLLAMA_BUILD_TOOLS=ON",
            "-DLLAMA_BUILD_UI=OFF", "-DLLAMA_BUILD_HTML=OFF", "-DLLAMA_OPENSSL=OFF",
            "-DGGML_CCACHE=OFF",                # keep build times honest
        ]
        env: dict = {}
        if target == "cpu":
            cc = cfg["compiler"]
            flags = [f"-{cfg['opt_level']}", "-DNDEBUG"]
            if cfg["fast_math"]:
                flags += ["-ffast-math", "-fno-finite-math-only"]   # ggml requires inf/nan support
            if cfg["unroll_loops"]:
                flags.append("-funroll-loops")
            if FLAGS(cfg) and cfg["mtune"] != "none":
                flags.append(f"-mtune={cfg['mtune']}")
            fl = " ".join(flags)
            all_var = cfg["cpu_variants"] == "all"
            args = common + [
                f"-DCMAKE_C_COMPILER={cc}", f"-DCMAKE_CXX_COMPILER={_cxx_for(cc)}",
                f"-DCMAKE_C_FLAGS_RELEASE={fl}", f"-DCMAKE_CXX_FLAGS_RELEASE={fl}",
                "-DGGML_CPU=ON", "-DGGML_HIP=OFF", "-DGGML_VULKAN=OFF", "-DGGML_CUDA=OFF",
                f"-DBUILD_SHARED_LIBS={_on(cfg['shared_libs'])}",
                f"-DGGML_BACKEND_DL={_on(all_var)}", f"-DGGML_CPU_ALL_VARIANTS={_on(all_var)}",
                f"-DGGML_NATIVE={_on(cfg['GGML_NATIVE'])}",
                f"-DGGML_OPENMP={_on(cfg['GGML_OPENMP'])}",
                f"-DGGML_LLAMAFILE={_on(cfg['GGML_LLAMAFILE'])}",
                f"-DGGML_CPU_REPACK={_on(cfg['GGML_CPU_REPACK'])}",
                f"-DGGML_LTO={_on(cfg['lto'])}",
                f"-DGGML_ZENDNN={_on(cfg['GGML_ZENDNN'])}",
            ]
            for k in ISA_REQUIRES:          # always explicit: ggml's defaults differ per option
                args.append(f"-D{k}={_on(cfg[k])}")
            if cfg["lto"] and cc.startswith("clang"):
                # clang LTO objects are LLVM bitcode: GNU ld/ar can't handle them
                v = cc.split("-")[1]
                args += [f"-DCMAKE_AR=/usr/bin/llvm-ar-{v}", f"-DCMAKE_RANLIB=/usr/bin/llvm-ranlib-{v}",
                         f"-DCMAKE_EXE_LINKER_FLAGS=-fuse-ld=lld-{v}",
                         f"-DCMAKE_SHARED_LINKER_FLAGS=-fuse-ld=lld-{v}"]
            if cfg["GGML_ZENDNN"]:
                args.append(f"-DZENDNN_ROOT={os.environ.get('ZENDNN_ROOT', '')}")
            if cfg["blas"] == "none":
                args.append("-DGGML_BLAS=OFF")
            else:
                args += ["-DGGML_BLAS=ON", f"-DGGML_BLAS_VENDOR={cfg['blas']}"]
                if cfg["blas"] == "AOCL_mt":
                    args.append(f"-DCMAKE_PREFIX_PATH={os.environ.get('AOCL_ROOT', '')}")
            return args, env

        if target == "cuda":
            cc = _cc_num(hw)
            # 'a' = arch-specific features (Blackwell FP4 tensor cores), as upstream does for 120/121
            arch = (f"{cc}a-real" if cc in ("120", "121") else f"{cc}-real") \
                if cfg["gpu_target"] == "exact" else f"{cc}-virtual"
            mmq = cfg["quant_matmul"]
            args = [x for x in common if not x.startswith("-DGGML_CCACHE")] + [
                f"-DGGML_CCACHE={'ON' if os.environ.get('HPCBENCH_CCACHE') == '1' else 'OFF'}",
                "-DBUILD_SHARED_LIBS=OFF", "-DGGML_CPU=ON", "-DGGML_NATIVE=ON",
                "-DGGML_CUDA=ON", "-DGGML_HIP=OFF", "-DGGML_VULKAN=OFF", "-DGGML_CUDA_NCCL=OFF",
                f"-DCMAKE_CUDA_COMPILER={shutil.which('nvcc') or 'nvcc'}",
                f"-DCMAKE_CUDA_ARCHITECTURES={arch}",
                f"-DCMAKE_CUDA_FLAGS_RELEASE=-O3 -DNDEBUG -Xptxas -{cfg['ptxas_opt']}",
                f"-DGGML_CUDA_GRAPHS={_on(cfg['GGML_CUDA_GRAPHS'])}",
                f"-DGGML_CUDA_FA={_on(cfg['GGML_CUDA_FA'])}",
                "-DGGML_CUDA_FA_ALL_QUANTS=OFF",
                f"-DGGML_CUDA_FORCE_MMQ={_on(mmq == 'force_mmq')}",
                f"-DGGML_CUDA_FORCE_CUBLAS={_on(mmq == 'force_cublas')}",
                f"-DGGML_CUDA_NO_VMM={_on(cfg['GGML_CUDA_NO_VMM'])}",
            ]
            return args, env

        if target == "vulkan":
            cc, level = cfg["compiler"], ISA_LEVEL[cfg["isa"]]
            fl = f"/{cfg['opt_level']} /DNDEBUG"
            args = common + [
                f"-DCMAKE_C_COMPILER={cc}", f"-DCMAKE_CXX_COMPILER={cc}",
                f"-DCMAKE_C_FLAGS_RELEASE={fl}", f"-DCMAKE_CXX_FLAGS_RELEASE={fl}",
                "-DGGML_CPU=ON", "-DGGML_VULKAN=ON", "-DGGML_HIP=OFF", "-DGGML_CUDA=OFF",
                f"-DBUILD_SHARED_LIBS={_on(cfg['shared_libs'])}",
                "-DGGML_BACKEND_DL=OFF", "-DGGML_CPU_ALL_VARIANTS=OFF",
                f"-DGGML_NATIVE={_on(not NOT_NATIVE(cfg))}",
                f"-DGGML_OPENMP={_on(cfg['GGML_OPENMP'])}",
                f"-DGGML_LLAMAFILE={_on(cfg['GGML_LLAMAFILE'])}",
                f"-DGGML_CPU_REPACK={_on(cfg['GGML_CPU_REPACK'])}",
                f"-DGGML_LTO={_on(cfg['lto'])}",
            ]
            if NOT_NATIVE(cfg):     # with GGML_NATIVE, ggml's FindSIMD.cmake probes and sets these itself
                args += [f"-DGGML_SSE42={_on(level >= 1)}", f"-DGGML_AVX={_on(level >= 2)}",
                         f"-DGGML_AVX2={_on(level >= 3)}", f"-DGGML_FMA={_on(level >= 3)}",
                         f"-DGGML_F16C={_on(level >= 3)}", f"-DGGML_BMI2={_on(cfg['GGML_BMI2'])}"]
                args += [f"-D{k}=OFF" for k in ISA_REQUIRES if k.startswith(("GGML_AVX512", "GGML_AMX", "GGML_AVX_VNNI"))]
            if cfg["lto"] and cc == "clang-cl":
                # clang LTO objects are LLVM bitcode: MSVC's link/lib can't handle them
                args += ["-DCMAKE_LINKER=lld-link", "-DCMAKE_AR=llvm-lib"]
            return args, env

        # ---- gpu target: host side fixed (native gcc -O3), vary the GPU side ----
        args = common + ["-DBUILD_SHARED_LIBS=OFF", "-DGGML_CPU=ON", "-DGGML_NATIVE=ON",
                         "-DGGML_CUDA=OFF", "-DCMAKE_C_COMPILER=gcc", "-DCMAKE_CXX_COMPILER=g++"]
        if cfg["backend"] == "vulkan":
            return args + ["-DGGML_VULKAN=ON", "-DGGML_HIP=OFF"], env

        rocm_llvm = subprocess.run(["hipconfig", "-l"], capture_output=True, text=True).stdout.strip()
        env["HIPCXX"] = f"{rocm_llvm}/clang"
        env["HIP_PATH"] = subprocess.run(["hipconfig", "-R"], capture_output=True, text=True).stdout.strip()
        gfx = os.environ.get("LLAMACPP_GPU_TARGETS") or hw.get("gpu_arch")
        mmq = cfg["mmq_mode"]
        hip_flags = f"-{cfg['hip_opt_level']} -DNDEBUG" + (" -munsafe-fp-atomics" if cfg["hip_unsafe_fp_atomics"] else "")
        args += [
            "-DGGML_VULKAN=OFF", "-DGGML_HIP=ON", f"-DGPU_TARGETS={gfx}",
            f"-DCMAKE_HIP_FLAGS_RELEASE={hip_flags}",
            f"-DGGML_HIP_GRAPHS={_on(cfg['GGML_HIP_GRAPHS'])}",
            f"-DGGML_HIP_NO_VMM={_on(cfg['GGML_HIP_NO_VMM'])}",
            f"-DGGML_HIP_MMQ_MFMA={_on(cfg['GGML_HIP_MMQ_MFMA'])}",
            f"-DGGML_CUDA_FA={_on(cfg['GGML_CUDA_FA'])}",
            f"-DGGML_CUDA_FA_ALL_QUANTS={_on(cfg['GGML_CUDA_FA_ALL_QUANTS'])}",
            f"-DGGML_CUDA_FORCE_MMQ={_on(mmq == 'force_mmq')}",
            f"-DGGML_CUDA_FORCE_CUBLAS={_on(mmq == 'force_blas')}",
        ]
        return args, env

    def validate_configure(self, cfg, target, build_dir: Path, log: Path) -> str | None:
        """CMake silently drops some options (e.g. OpenMP not found -> threadpool).
        Catch that, otherwise the record would claim a configuration that was never built."""
        if target not in ("cpu", "vulkan"):
            return None
        cache = (build_dir / "CMakeCache.txt").read_text(errors="replace")
        text = log.read_text(errors="replace")
        if cfg["GGML_OPENMP"] and "GGML_OPENMP_ENABLED:INTERNAL=ON" not in cache:
            return "config_not_applied:openmp"
        if cfg["lto"] and "IPO is not supported" in text:
            return "config_not_applied:lto"
        return None

    # ------------------------------------------------------------------ #
    def runtime_params(self, target, hw, overrides):
        rt = {
            "model": str(self.default_model()),
            "n_prompt": 512,
            "n_gen": 128,
            "repetitions": 5,
            "threads": min(hw.get("cpu_cores") or os.cpu_count(),
                           hw.get("cpu_cores_allocated") or os.cpu_count()),
            "n_gpu_layers": 0 if target == "cpu" else 99,
            "flash_attn": "on" if target == "cpu" else "auto",
            "batch_size": 2048,
            "ubatch_size": 512,
            "pin_cpus": None,           # e.g. "0-7" -> taskset
            "timeout_s": 1800,
        }
        for k, v in overrides.items():
            if k not in rt:
                raise SystemExit(f"unknown runtime parameter {k!r}; known: {sorted(rt)}")
            rt[k] = type(rt[k])(v) if rt[k] is not None else v
        model = Path(rt["model"]).resolve()
        rt["model"] = str(model)
        rt["model_sha256"] = sha256_cached(model) if model.exists() else None
        return rt

    # protocol = everything that must be identical across machines for results to be comparable
    PROTOCOL_KEYS = ["model_sha256", "n_prompt", "n_gen", "repetitions", "n_gpu_layers",
                     "flash_attn", "batch_size", "ubatch_size"]

    def run(self, binary, target, runtime, log, env=None):
        model = Path(runtime["model"])
        if not model.exists():
            return "missing_model", {}, None
        cmd = [str(binary), "-m", str(model), "-o", "json",
               "-p", str(runtime["n_prompt"]), "-n", str(runtime["n_gen"]),
               "-r", str(runtime["repetitions"]), "-t", str(runtime["threads"]),
               "-ngl", str(runtime["n_gpu_layers"]), "-fa", runtime["flash_attn"],
               "-b", str(runtime["batch_size"]), "-ub", str(runtime["ubatch_size"])]
        if runtime.get("pin_cpus"):
            cmd = ["taskset", "-c", str(runtime["pin_cpus"])] + cmd
        pre = os.environ.get("HPCBENCH_PRE_RUN")       # e.g. /usr/bin/drop-caches on GB10 nodes
        if pre:
            run_cmd(["bash", "-c", pre], log)
        profile = None
        if os.name == "nt":     # Windows: CPU profile from the kernel's per-process counters
            from ..winprof import run_profiled
            rc, secs, out, profile = run_profiled(cmd, log, env=env, timeout=runtime["timeout_s"])
        else:
            rc, secs, out = run_cmd(cmd, log, capture=True, timeout=runtime["timeout_s"], env=env)
        if rc == -999:
            return "timeout", {"run_time_s": secs}, None
        if rc != 0:
            # 0xC000001D = STATUS_ILLEGAL_INSTRUCTION on Windows
            status = "illegal_instruction" if rc in (-4, 132, 0xC000001D) else f"run_failed(rc={rc})"
            return status, {"run_time_s": secs}, None
        try:
            entries = json.loads(out)
        except json.JSONDecodeError:
            return "parse_failed", {"run_time_s": secs}, out[-2000:]

        m: dict = {"run_time_s": round(secs, 3)}
        if profile:
            m["cpu_profile"] = profile
        for e in entries:
            key = f"pp{e['n_prompt']}" if e["n_gen"] == 0 else f"tg{e['n_gen']}"
            m[f"{key}_tps"] = e["avg_ts"]
            m[f"{key}_tps_std"] = e["stddev_ts"]
            m[f"{key}_tps_cv"] = e["stddev_ts"] / e["avg_ts"] if e["avg_ts"] else None
            m[f"{key}_samples_tps"] = e.get("samples_ts")
        first = entries[0] if entries else {}
        m["llama_backends"] = first.get("backends")
        m["llama_build_commit"] = first.get("build_commit")
        m["model_type"] = first.get("model_type")
        m["gpu_info"] = first.get("gpu_info")

        if target in ("gpu", "cuda", "vulkan") and not any(b in (first.get("backends") or "")
                                                 for b in ("ROCm", "HIP", "Vulkan", "CUDA")):
            return "wrong_backend", m, entries
        return "ok", m, entries
