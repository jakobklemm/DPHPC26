"""Application adapters. Add a new app by subclassing App/CMakeApp and
registering it in APPS below."""
from __future__ import annotations

import os
import shutil
from pathlib import Path

from ..core import ConfigSpace, run_cmd


class App:
    name: str = ""
    targets: dict[str, ConfigSpace] = {}

    def default_src(self) -> Path:
        raise NotImplementedError

    def check_supported(self, cfg: dict, target: str, hw: dict) -> str | None:
        """Return a reason string if this config can't run on this machine, else None."""
        return None

    def runtime_params(self, target: str, hw: dict, overrides: dict) -> dict:
        raise NotImplementedError

    def build(self, cfg: dict, target: str, src: Path, build_dir: Path, hw: dict,
              log: Path, jobs: int) -> tuple[str, float, Path | None]:
        raise NotImplementedError

    def build_part(self, cfg: dict, target: str) -> dict:
        """The parameters that change the binary; configs that agree on them share one build."""
        return cfg

    def run_env(self, cfg: dict, target: str) -> dict:
        """Environment variables for the benchmark run that follow from the config."""
        return {}

    def run(self, binary: Path, target: str, runtime: dict, log: Path,
            env: dict | None = None) -> tuple[str, dict, object]:
        raise NotImplementedError


class CMakeApp(App):
    """Configure + build one target with CMake/Ninja."""
    build_target: str = ""
    binary_rel: str = ""

    def cmake_args(self, cfg: dict, target: str, hw: dict) -> tuple[list[str], dict]:
        raise NotImplementedError

    def validate_configure(self, cfg: dict, target: str, build_dir: Path, log: Path) -> str | None:
        return None

    def prune_build(self, build_dir: Path) -> None:
        """Keep only what is needed to re-run: bin/ (executable + any .so) and CMakeCache.txt.
        Paths stay unchanged, so RPATHs of shared-lib builds keep working."""
        for p in build_dir.iterdir():
            if p.name in ("bin", "CMakeCache.txt"):
                continue
            shutil.rmtree(p) if p.is_dir() and not p.is_symlink() else p.unlink()

    def build(self, cfg, target, src, build_dir, hw, log, jobs):
        binary = build_dir / self.binary_rel
        args, env = self.cmake_args(cfg, target, hw)
        gen = ["-G", "Ninja"] if shutil.which("ninja") else []
        total = 0.0
        rc, t, _ = run_cmd(["cmake", "-S", str(src), "-B", str(build_dir), *gen, *args],
                           log, env=env)
        total += t
        if rc != 0:
            return "configure_failed", total, None
        bad = self.validate_configure(cfg, target, build_dir, log)
        if bad:
            return bad, total, None
        rc, t, _ = run_cmd(["cmake", "--build", str(build_dir), "--target", self.build_target,
                            "-j", str(jobs)], log, env=env)
        total += t
        if rc != 0 or not binary.exists():
            return "build_failed", total, None
        return "ok", total, binary


def _registry():
    from .llamacpp import LlamaCpp
    return {a.name: a for a in [LlamaCpp()]}


def get_app(name: str) -> App:
    apps = _registry()
    if name not in apps:
        raise SystemExit(f"unknown app {name!r}; available: {sorted(apps)}")
    return apps[name]


def jobs_default() -> int:
    try:
        return max(1, len(os.sched_getaffinity(0)))   # respects Slurm's core limit
    except AttributeError:
        return max(1, (os.cpu_count() or 2))
